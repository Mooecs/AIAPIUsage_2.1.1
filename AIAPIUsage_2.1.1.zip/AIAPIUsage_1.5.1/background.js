/**
 * AI API Toolkit - Background Service Worker
 *
 * Handles API requests in the service worker context to:
 * 1. Bypass CORS restrictions
 * 2. Automatically send cf_clearance cookies (credentials: "include")
 *
 * Supports multiple API formats:
 * - new-api: GET {base_url}/api/usage/token
 * - one-api: GET {base_url}/api/user/self
 * - sub2api: GET {base_url}/v1/usage
 * - cch:     POST {base_url}/api/actions/my-usage/* (Claude Code Hub)
 * - openai:  GET billing/models compatible endpoints
 */

// Error categories for structured error handling
const ErrorType = {
  NETWORK: 'network',
  AUTH: 'auth',
  CHALLENGE: 'challenge',
  FORMAT: 'format',
  TIMEOUT: 'timeout',
  UNKNOWN: 'unknown',
};

const QUERY_TIMEOUT_MS = 10000;
const POST_QUERY_TIMEOUT_MS = 12000;
const OPTIONAL_POST_TIMEOUT_MS = 5000;
const HEALTH_TIMEOUT_MS = 5000;
const TAB_FETCH_TIMEOUT_MS = 12000;
const USAGE_CACHE_TTL_MS = 15000;
const MAX_CACHE_SIZE = 100;

const usageQueryCache = new Map();
const inflightUsageQueries = new Map();

/**
 * Classify an error or HTTP response into an error category.
 */
function classifyError(error, response) {
  if (error) {
    if (error.name === 'AbortError') return ErrorType.TIMEOUT;
    return ErrorType.NETWORK;
  }
  if (!response) return ErrorType.UNKNOWN;
  if (response.status === 401) return ErrorType.AUTH;
  if (response.status === 403 || response.status === 503) {
    // Check if it's a Cloudflare challenge vs auth failure
    const ct = response.headers.get('content-type') || '';
    if (!ct.includes('application/json')) return ErrorType.CHALLENGE;
    return ErrorType.AUTH;
  }
  // 404/405 likely means wrong endpoint format — retriable
  if (response.status === 404 || response.status === 405) return ErrorType.FORMAT;
  return ErrorType.UNKNOWN;
}

/**
 * Extract the origin (scheme + host + port) from a URL string.
 */
function getOrigin(url) {
  try {
    const u = new URL(url);
    return u.origin;
  } catch {
    return null;
  }
}

/**
 * Find an existing tab whose URL shares the same origin as `targetUrl`.
 */
async function findTabForOrigin(targetUrl) {
  const origin = getOrigin(targetUrl);
  if (!origin) return null;
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (tab.url && getOrigin(tab.url) === origin) return tab;
  }
  return null;
}

/**
 * Wait for a tab to reach 'complete' status with timeout.
 */
function waitForTabComplete(tabId, timeoutMs = 8000) {
  return new Promise((resolve) => {
    const onUpdated = (_tabId, info) => {
      if (_tabId === tabId && info.status === 'complete') {
        cleanup();
        resolve();
      }
    };
    const timer = setTimeout(() => {
      cleanup();
      resolve();
    }, timeoutMs);

    function cleanup() {
      chrome.tabs.onUpdated.removeListener(onUpdated);
      clearTimeout(timer);
    }

    chrome.tabs.onUpdated.addListener(onUpdated);
  });
}

/**
 * Execute a fetch request inside a tab's page context.
 * Supports GET and POST.
 */
async function fetchViaTab(tabId, url, options = {}) {
  const { method = 'GET', headers = {}, body = null, timeoutMs = TAB_FETCH_TIMEOUT_MS } = options;
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    args: [url, { method, headers, body, timeoutMs }],
    func: async (_url, _opt) => {
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), _opt.timeoutMs);
        const resp = await fetch(_url, {
          method: _opt.method,
          headers: _opt.headers,
          body: _opt.body ? JSON.stringify(_opt.body) : undefined,
          credentials: 'include',
          signal: controller.signal,
        });
        clearTimeout(timer);
        const contentType = resp.headers.get('content-type') || '';
        const text = await resp.text();
        return {
          ok: resp.ok,
          status: resp.status,
          statusText: resp.statusText,
          contentType,
          text,
        };
      } catch (err) {
        return { error: true, message: err.message, name: err.name };
      }
    },
  });

  if (!results || results.length === 0) {
    throw new Error('executeScript 返回空结果');
  }
  return results[0].result;
}
/**
 * Check if a fetch response looks like a Cloudflare challenge page.
 */
function isCfChallenge(response) {
  if (!response) return false;
  if (response.status !== 403 && response.status !== 503) return false;
  const ct = response.headers.get('content-type') || '';
  return !ct.includes('application/json');
}

/**
 * Wrap a tabResult (plain object from executeScript) into a Response-like
 * shape that tryEndpoint can consume.
 */
function wrapTabResult(tabResult) {
  if (tabResult && tabResult.error) {
    const err = new Error(tabResult.message);
    err.name = tabResult.name || 'Error';
    return { response: null, error: err };
  }
  const fakeResponse = {
    ok: tabResult.ok,
    status: tabResult.status,
    statusText: tabResult.statusText,
    headers: {
      get(name) {
        if (name.toLowerCase() === 'content-type') return tabResult.contentType;
        return null;
      },
    },
    json: async () => JSON.parse(tabResult.text),
    text: async () => tabResult.text,
  };
  return { response: fakeResponse, error: null };
}

/**
 * Fetch via tab: find an existing tab on the same origin, or create a
 * temporary background tab, execute the fetch there, then clean up.
 */
async function fetchViaTabWithFallback(url, options = {}) {
  let tab = await findTabForOrigin(url);
  let tempTab = false;

  if (!tab) {
    const origin = getOrigin(url);
    if (!origin) throw new Error('invalid origin');
    tab = await chrome.tabs.create({ url: origin, active: false });
    tempTab = true;
    await waitForTabComplete(tab.id);
  }

  try {
    const tabResult = await fetchViaTab(tab.id, url, options);
    return wrapTabResult(tabResult);
  } finally {
    if (tempTab) {
      try { await chrome.tabs.remove(tab.id); } catch { /* ignore */ }
    }
  }
}

/**
 * Make a fetch request.
 * 1. Direct service-worker fetch first (fast path, works for non-CF sites).
 * 2. If the response looks like a Cloudflare challenge (403/503 + non-JSON),
 *    automatically retry via a tab on the same origin (carries cookies + UA).
 */
async function fetchWithTimeout(url, headers, timeoutMs = QUERY_TIMEOUT_MS) {
  // ---- Fast path: direct service-worker fetch ----
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        Accept: 'application/json, text/plain, */*',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'Cache-Control': 'no-cache',
        Pragma: 'no-cache',
        ...headers,
      },
      cache: 'no-store',
      credentials: 'include',
      signal: controller.signal,
    });
    clearTimeout(timer);

    // If it looks like a CF challenge, retry via tab
    if (isCfChallenge(response)) {
      try {
        return await fetchViaTabWithFallback(url, { method: 'GET', headers });
      } catch {
        // Tab approach failed, return the original CF response
        return { response, error: null };
      }
    }

    return { response, error: null };
  } catch (error) {
    clearTimeout(timer);
    return { response: null, error };
  }
}

/**
 * Try to query a specific API endpoint and parse the result.
 */
async function tryEndpoint(url, apiKey) {
  const headers = { Authorization: `Bearer ${apiKey}` };
  const { response, error } = await fetchWithTimeout(url, headers, QUERY_TIMEOUT_MS);

  if (error) {
    const errorType = classifyError(error, null);
    return {
      success: false,
      errorType,
      message:
        errorType === ErrorType.TIMEOUT
          ? '请求超时，请检查网络或站点是否可达'
          : `网络错误: ${error.message}`,
    };
  }

  if (!response.ok) {
    const errorType = classifyError(null, response);
    let message;
    switch (errorType) {
      case ErrorType.AUTH:
        message = `认证失败 (${response.status})，请检查 API Key 是否正确`;
        break;
      case ErrorType.CHALLENGE:
        message =
          'Cloudflare 机检未通过，请先在浏览器中打开该站点并保持标签页不关闭，再重试查额';
        break;
      default:
        message = `HTTP ${response.status}: ${response.statusText}`;
    }
    return { success: false, errorType, message };
  }

  // Check content-type to ensure we have JSON
  const ct = response.headers.get('content-type') || '';
  if (!ct.includes('application/json')) {
    return {
      success: false,
      errorType: ErrorType.FORMAT,
      message: '响应不是 JSON 格式，可能被 Cloudflare 拦截',
    };
  }

  try {
    const data = await response.json();
    return { success: true, data };
  } catch {
    return {
      success: false,
      errorType: ErrorType.FORMAT,
      message: 'JSON 解析失败',
    };
  }
}

/**
 * Normalize base URL: remove trailing slash.
 */
function normalizeUrl(url) {
  return url.replace(/\/+$/, '');
}

function cloneResult(result) {
  if (typeof structuredClone === 'function') {
    return structuredClone(result);
  }
  return JSON.parse(JSON.stringify(result));
}

function getUsageQueryKey(site) {
  return `${normalizeUrl(site.baseUrl || '')}::${site.apiKey || ''}`;
}

function getCachedUsageQuery(key) {
  const cached = usageQueryCache.get(key);
  if (!cached) return null;
  if (Date.now() - cached.timestamp > USAGE_CACHE_TTL_MS) {
    usageQueryCache.delete(key);
    return null;
  }
  return cloneResult(cached.result);
}

function setCachedUsageQuery(key, result) {
  if (usageQueryCache.size >= MAX_CACHE_SIZE) {
    const oldest = usageQueryCache.keys().next().value;
    usageQueryCache.delete(oldest);
  }
  usageQueryCache.set(key, {
    timestamp: Date.now(),
    result: cloneResult(result),
  });
}

function getUsageEndpointChecks(baseUrl) {
  return [
    { format: 'new-api', url: `${baseUrl}/api/usage/token` },
    { format: 'one-api', url: `${baseUrl}/api/user/self` },
    { format: 'sub2api', url: `${baseUrl}/v1/usage` },
  ];
}

async function probeUsageEndpoints(baseUrl, apiKey) {
  const checks = getUsageEndpointChecks(baseUrl);
  const results = await Promise.all(
    checks.map(async (check) => ({
      format: check.format,
      result: await tryEndpoint(check.url, apiKey),
    })),
  );
  return results;
}

function pickSuccessfulUsageProbe(probes) {
  for (const probe of probes) {
    if (probe.result && probe.result.success) {
      return {
        success: true,
        format: detectFormatFromData(probe.result.data) || probe.format,
        data: probe.result.data,
      };
    }
  }
  return null;
}

function pickMostRelevantError(results) {
  const priority = {
    [ErrorType.AUTH]: 0,
    [ErrorType.CHALLENGE]: 1,
    [ErrorType.TIMEOUT]: 2,
    [ErrorType.NETWORK]: 3,
    [ErrorType.UNKNOWN]: 4,
    [ErrorType.FORMAT]: 5,
  };

  let best = null;
  for (const result of results) {
    if (!result || result.success || !result.errorType) continue;
    if (!best || priority[result.errorType] < priority[best.errorType]) {
      best = result;
    }
  }
  return best;
}

function mergeRelevantErrors(...resultSets) {
  return pickMostRelevantError(resultSets.flat().filter(Boolean));
}

function createDebugStep({ format, endpoint, method = 'GET', status = 'info', message, errorType }) {
  return {
    format,
    endpoint,
    method,
    status,
    message,
    errorType: errorType || null,
  };
}

function appendDebugSteps(target, steps) {
  if (!Array.isArray(target) || !Array.isArray(steps) || steps.length === 0) return;
  target.push(...steps);
}

/**
 * Detect the API format from the response data structure.
 * - isValid field present → sub2api
 * - one-api user/self payload → one-api
 * - new-api quota payload → new-api
 * - quota + todayStats (merged CCH) → cch
 * - OpenAI-compatible billing/models → openai
 */
function unwrapStructuredData(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) return data;
  if (data.success !== undefined && data.data && typeof data.data === 'object' && !Array.isArray(data.data)) {
    return data.data;
  }
  if ('data' in data && data.data && typeof data.data === 'object' && !Array.isArray(data.data)) {
    return data.data;
  }
  return data;
}

function isSub2apiData(data) {
  return Boolean(
    data && typeof data === 'object' && !Array.isArray(data) && (
      'isValid' in data ||
      (
        data.quota &&
        typeof data.quota === 'object' &&
        (
          'mode' in data ||
          'planName' in data ||
          'usage' in data ||
          'model_stats' in data
        )
      )
    )
  );
}

function isCCHData(data) {
  return Boolean(
    data && typeof data === 'object' && !Array.isArray(data) &&
    ('keyCurrent5hUsd' in data || 'keyCurrentDailyUsd' in data)
  );
}

function isOneApiData(rawData) {
  const data = unwrapStructuredData(rawData);
  return Boolean(
    data && typeof data === 'object' && !Array.isArray(data) && (
      'used_quota' in data ||
      'request_count' in data ||
      'group' in data ||
      'aff_code' in data ||
      (
        'quota' in data &&
        typeof data.quota !== 'object'
      ) ||
      (
        'role' in data &&
        ('username' in data || 'display_name' in data || 'email' in data)
      )
    )
  );
}

function isNewApiData(rawData) {
  const data = unwrapStructuredData(rawData);
  return Boolean(
    data && typeof data === 'object' && !Array.isArray(data) && (
      'total_granted' in data ||
      'total_used' in data ||
      'total_available' in data ||
      'unlimited_quota' in data ||
      'expires_at' in data ||
      'model_limits' in data
    )
  );
}

function isOpenAIModelsData(data) {
  if (Array.isArray(data)) {
    return data.every((item) => item && typeof item === 'object' && ('id' in item || 'name' in item || 'object' in item));
  }
  return Boolean(
    data &&
    typeof data === 'object' &&
    !Array.isArray(data) &&
    Array.isArray(data.data) &&
    (data.object === 'list' || data.data.every((item) => item && typeof item === 'object' && ('id' in item || 'object' in item)))
  );
}

function isOpenAIBillingData(data) {
  return Boolean(
    data && typeof data === 'object' && !Array.isArray(data) && (
      'hard_limit_usd' in data ||
      'system_hard_limit_usd' in data ||
      'access_until' in data ||
      'total_available' in data ||
      'total_granted' in data ||
      'total_used' in data ||
      (data.grants && typeof data.grants === 'object')
    )
  );
}

function detectFormatFromData(data) {
  if (isSub2apiData(data)) return 'sub2api';
  if (isCCHData(data)) return 'cch';
  if (isOneApiData(data)) return 'one-api';
  if (isNewApiData(data)) return 'new-api';
  if (isOpenAIBillingData(data) || isOpenAIModelsData(data)) return 'openai';
  return null;
}

function normalizeOpenAIBillingData(subscriptionData, creditData) {
  const grants = creditData && creditData.grants && typeof creditData.grants === 'object' ? creditData.grants : null;
  const totalGranted = Number(
    creditData?.total_granted ??
    grants?.total_granted ??
    subscriptionData?.hard_limit_usd ??
    subscriptionData?.system_hard_limit_usd ??
    0
  );
  const totalAvailable = Number(
    creditData?.total_available ??
    grants?.total_available ??
    0
  );
  const explicitUsed = creditData?.total_used ?? grants?.total_used;
  const totalUsed = explicitUsed != null ? Number(explicitUsed) : Math.max(totalGranted - totalAvailable, 0);

  return {
    _openaiUsageType: 'billing',
    total_granted: totalGranted,
    total_available: totalAvailable,
    total_used: totalUsed,
    hard_limit_usd: Number(subscriptionData?.hard_limit_usd ?? subscriptionData?.system_hard_limit_usd ?? totalGranted),
    access_until: subscriptionData?.access_until ?? creditData?.access_until ?? null,
    plan: subscriptionData?.plan?.title ?? subscriptionData?.account_name ?? null,
    has_payment_method: subscriptionData?.has_payment_method ?? null,
    subscription: subscriptionData || null,
    credit_grants: creditData || null,
  };
}

/**
 * Try to query CCH (Claude Code Hub) usage via REST API.
 * Calls getMyQuota (required) + getMyTodayStats (optional) in parallel.
 * Auth: Bearer token (same value as Cookie auth-token, both are supported by CCH).
 */
async function queryCCHUsage(baseUrl, apiKey) {
  const quotaUrl = `${baseUrl}/api/actions/my-usage/getMyQuota`;
  const todayUrl = `${baseUrl}/api/actions/my-usage/getMyTodayStats`;
  const headers = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${apiKey}`,
  };

  // Fetch quota (required) and today stats (optional) in parallel.
  // Use Promise.allSettled so todayStats timeout doesn't block quota.
  const [quotaResult, todaySettled] = await Promise.allSettled([
    fetchPostWithTimeout(quotaUrl, headers, {}, POST_QUERY_TIMEOUT_MS),
    fetchPostWithTimeout(todayUrl, headers, {}, OPTIONAL_POST_TIMEOUT_MS),
  ]);

  // Unwrap quota result (required)
  if (quotaResult.status === 'rejected' || quotaResult.value.error) {
    const err = quotaResult.status === 'rejected' ? quotaResult.reason : quotaResult.value.error;
    const errorType = classifyError(err, null);
    return {
      success: false,
      errorType,
      debugSteps: [
        createDebugStep({
          format: 'cch',
          endpoint: quotaUrl,
          method: 'POST',
          status: 'error',
          errorType,
          message:
            errorType === ErrorType.TIMEOUT
              ? 'getMyQuota 请求超时'
              : `getMyQuota 网络错误: ${err.message}`,
        }),
      ],
      message:
        errorType === ErrorType.TIMEOUT
          ? '请求超时'
          : `网络错误: ${err.message}`,
    };
  }
  const qr = quotaResult.value;

  if (!qr.response.ok) {
    const errorType = classifyError(null, qr.response);
    if (errorType === ErrorType.FORMAT) {
      // 404/405 → not a CCH instance
      return { success: false, errorType: ErrorType.FORMAT, message: '非 CCH 实例' };
    }
    let message;
    switch (errorType) {
      case ErrorType.AUTH:
        message = `认证失败 (${qr.response.status})，请检查 API Key`;
        break;
      case ErrorType.CHALLENGE:
        message = 'Cloudflare 机检未通过';
        break;
      default:
        message = `HTTP ${qr.response.status}`;
    }
    return {
      success: false,
      errorType,
      message,
      debugSteps: [
        createDebugStep({
          format: 'cch',
          endpoint: quotaUrl,
          method: 'POST',
          status: 'error',
          errorType,
          message,
        }),
      ],
    };
  }

  // Check content-type
  const ct = qr.response.headers.get('content-type') || '';
  if (!ct.includes('application/json')) {
    return {
      success: false,
      errorType: ErrorType.FORMAT,
      message: '响应不是 JSON',
      debugSteps: [
        createDebugStep({
          format: 'cch',
          endpoint: quotaUrl,
          method: 'POST',
          status: 'error',
          errorType: ErrorType.FORMAT,
          message: 'getMyQuota 返回非 JSON 响应',
        }),
      ],
    };
  }

  try {
    const quotaData = await qr.response.json();
    if (!quotaData.ok || !quotaData.data) {
      return {
        success: false,
        errorType: ErrorType.FORMAT,
        message: quotaData.error || '非 CCH 响应',
        debugSteps: [
          createDebugStep({
            format: 'cch',
            endpoint: quotaUrl,
            method: 'POST',
            status: 'error',
            errorType: ErrorType.FORMAT,
            message: quotaData.error || 'getMyQuota 结构不符合 CCH',
          }),
        ],
      };
    }

    // Verify it's actually CCH data
    if (!('keyCurrent5hUsd' in quotaData.data) && !('keyCurrentDailyUsd' in quotaData.data)) {
      return {
        success: false,
        errorType: ErrorType.FORMAT,
        message: '非 CCH 响应结构',
        debugSteps: [
          createDebugStep({
            format: 'cch',
            endpoint: quotaUrl,
            method: 'POST',
            status: 'error',
            errorType: ErrorType.FORMAT,
            message: '缺少 CCH 额度字段',
          }),
        ],
      };
    }

    // Parse today stats (optional, don't fail if this errors)
    let todayData = null;
    try {
      const todayResult = todaySettled.status === 'fulfilled' ? todaySettled.value : null;
      if (todayResult && todayResult.response && todayResult.response.ok) {
        const todayJson = await todayResult.response.json();
        if (todayJson.ok && todayJson.data) {
          todayData = todayJson.data;
        }
      }
    } catch { /* today stats are optional */ }

    // Merge into single data object
    return {
      success: true,
      data: {
        ...quotaData.data,
        todayStats: todayData,
      },
      debugSteps: [
        createDebugStep({
          format: 'cch',
          endpoint: quotaUrl,
          method: 'POST',
          status: 'success',
          message: 'getMyQuota 查询成功',
        }),
        createDebugStep({
          format: 'cch',
          endpoint: todayUrl,
          method: 'POST',
          status: todayData ? 'success' : 'info',
          message: todayData ? 'getMyTodayStats 查询成功' : 'getMyTodayStats 未返回可用数据',
        }),
      ],
    };
  } catch {
    return {
      success: false,
      errorType: ErrorType.FORMAT,
      message: 'JSON 解析失败',
      debugSteps: [
        createDebugStep({
          format: 'cch',
          endpoint: quotaUrl,
          method: 'POST',
          status: 'error',
          errorType: ErrorType.FORMAT,
          message: 'CCH 响应 JSON 解析失败',
        }),
      ],
    };
  }
}

/**
 * Try to query OneAPI usage via /api/user/self endpoint.
 */
async function queryOneApiUsage(baseUrl, apiKey) {
  const url = `${baseUrl}/api/user/self`;
  const result = await tryEndpoint(url, apiKey);
  if (!result.success) {
    return {
      ...result,
      debugSteps: [
        createDebugStep({
          format: 'one-api',
          endpoint: url,
          method: 'GET',
          status: 'error',
          errorType: result.errorType,
          message: result.message,
        }),
      ],
    };
  }

  const data = result.data;
  // OneAPI wraps in { success: true, data: {...} } or returns directly
  const userData = (data && data.data) || data;
  if (!userData || typeof userData !== 'object') {
    return {
      success: false,
      errorType: ErrorType.FORMAT,
      message: '非 OneAPI 响应',
      debugSteps: [
        createDebugStep({
          format: 'one-api',
          endpoint: url,
          method: 'GET',
          status: 'error',
          errorType: ErrorType.FORMAT,
          message: '响应结构不是 OneAPI 用户信息',
        }),
      ],
    };
  }
  // Verify it's OneAPI data
  if (!('quota' in userData || 'used_quota' in userData || 'role' in userData)) {
    return {
      success: false,
      errorType: ErrorType.FORMAT,
      message: '非 OneAPI 响应结构',
      debugSteps: [
        createDebugStep({
          format: 'one-api',
          endpoint: url,
          method: 'GET',
          status: 'error',
          errorType: ErrorType.FORMAT,
          message: '缺少 OneAPI 关键字段',
        }),
      ],
    };
  }

  return {
    success: true,
    data: userData,
    debugSteps: [
      createDebugStep({
        format: 'one-api',
        endpoint: url,
        method: 'GET',
        status: 'success',
        message: 'OneAPI 用户信息查询成功',
      }),
    ],
  };
}

async function queryOpenAIUsage(baseUrl, apiKey) {
  const billingEndpointPairs = [
    {
      subscriptionUrl: `${baseUrl}/dashboard/billing/subscription`,
      creditUrl: `${baseUrl}/dashboard/billing/credit_grants`,
    },
    {
      subscriptionUrl: `${baseUrl}/v1/dashboard/billing/subscription`,
      creditUrl: `${baseUrl}/v1/dashboard/billing/credit_grants`,
    },
  ];

  let bestError = null;

  for (const pair of billingEndpointPairs) {
    const [subscriptionResult, creditResult] = await Promise.all([
      tryEndpoint(pair.subscriptionUrl, apiKey),
      tryEndpoint(pair.creditUrl, apiKey),
    ]);

    const subscriptionOk = subscriptionResult.success && isOpenAIBillingData(subscriptionResult.data);
    const creditOk = creditResult.success && isOpenAIBillingData(creditResult.data);

    if (subscriptionOk || creditOk) {
      return {
        success: true,
        data: normalizeOpenAIBillingData(
          subscriptionOk ? subscriptionResult.data : null,
          creditOk ? creditResult.data : null,
        ),
        debugSteps: [
          createDebugStep({
            format: 'openai',
            endpoint: pair.subscriptionUrl,
            method: 'GET',
            status: subscriptionOk ? 'success' : 'info',
            message: subscriptionOk ? 'subscription 计费信息查询成功' : (subscriptionResult.message || 'subscription 未返回可用计费数据'),
            errorType: subscriptionOk ? null : subscriptionResult.errorType,
          }),
          createDebugStep({
            format: 'openai',
            endpoint: pair.creditUrl,
            method: 'GET',
            status: creditOk ? 'success' : 'info',
            message: creditOk ? 'credit_grants 查询成功' : (creditResult.message || 'credit_grants 未返回可用计费数据'),
            errorType: creditOk ? null : creditResult.errorType,
          }),
        ],
      };
    }

    bestError = mergeRelevantErrors(bestError, subscriptionResult, creditResult) || bestError;
  }

  const modelsResult = await tryEndpoint(`${baseUrl}/v1/models`, apiKey);
  if (modelsResult.success && isOpenAIModelsData(modelsResult.data)) {
    if (Array.isArray(modelsResult.data)) {
      return {
        success: true,
        data: modelsResult.data,
        debugSteps: [
          createDebugStep({
            format: 'openai',
            endpoint: `${baseUrl}/v1/models`,
            method: 'GET',
            status: 'success',
            message: 'v1/models 查询成功',
          }),
        ],
      };
    }
    return {
      success: true,
      data: {
        ...modelsResult.data,
        _openaiUsageType: 'models',
      },
      debugSteps: [
        createDebugStep({
          format: 'openai',
          endpoint: `${baseUrl}/v1/models`,
          method: 'GET',
          status: 'success',
          message: 'v1/models 查询成功',
        }),
      ],
    };
  }

  bestError = mergeRelevantErrors(bestError, modelsResult) || bestError;
  if (bestError) {
    return {
      success: false,
      errorType: bestError.errorType,
      message: bestError.message,
      debugSteps: [
        ...billingEndpointPairs.flatMap((pair) => ([
          createDebugStep({
            format: 'openai',
            endpoint: pair.subscriptionUrl,
            method: 'GET',
            status: 'error',
            errorType: bestError.errorType,
            message: 'subscription 端点未获得可用结果',
          }),
          createDebugStep({
            format: 'openai',
            endpoint: pair.creditUrl,
            method: 'GET',
            status: 'error',
            errorType: bestError.errorType,
            message: 'credit_grants 端点未获得可用结果',
          }),
        ])),
        createDebugStep({
          format: 'openai',
          endpoint: `${baseUrl}/v1/models`,
          method: 'GET',
          status: 'error',
          errorType: modelsResult.errorType,
          message: modelsResult.message || 'v1/models 未获得可用结果',
        }),
      ],
    };
  }

  return { success: false, errorType: ErrorType.FORMAT, message: '非 OpenAI 兼容响应' };
}

/**
 * Health check: ping a URL to see if it's alive.
 */
async function healthCheck(baseUrl) {
  const start = Date.now();
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), HEALTH_TIMEOUT_MS);
    const response = await fetch(baseUrl, {
      method: 'HEAD',
      signal: controller.signal,
      credentials: 'include',
    });
    clearTimeout(timer);
    const latency = Date.now() - start;
    const server = response.headers.get('server') || '';
    return { alive: true, latency, status: response.status, server };
  } catch (err) {
    // HEAD might be blocked, try GET
    try {
      const controller2 = new AbortController();
      const timer2 = setTimeout(() => controller2.abort(), HEALTH_TIMEOUT_MS);
      const response2 = await fetch(baseUrl, {
        method: 'GET',
        signal: controller2.signal,
        credentials: 'include',
      });
      clearTimeout(timer2);
      const latency = Date.now() - start;
      const server = response2.headers.get('server') || '';
      return { alive: true, latency, status: response2.status, server };
    } catch (err2) {
      return { alive: false, error: err2.message };
    }
  }
}

/**
 * Detect API format by trying multiple endpoints.
 */
async function detectApiFormat(baseUrl, apiKey) {
  const normalizedUrl = normalizeUrl(baseUrl);
  const startTime = Date.now();

  // First check if site is alive
  const health = await healthCheck(normalizedUrl);
  if (!health.alive) {
    return { alive: false, error: health.error };
  }

  const result = { alive: true, latency: health.latency, detectedFormat: null, serverInfo: health.server || null };

  if (!apiKey) {
    return result;
  }

  // Probe the common GET-based formats in parallel to shorten cold-start detection.
  try {
    const probes = await probeUsageEndpoints(normalizedUrl, apiKey);
    const detected = pickSuccessfulUsageProbe(probes);
    if (detected) {
      result.detectedFormat = detected.format;
      return result;
    }

    const authProbe = probes.find((probe) => probe.result && probe.result.errorType === ErrorType.AUTH);
    if (authProbe) {
      result.detectedFormat = authProbe.format;
      return result;
    }
  }
  catch { /* continue */ }

  // Try CCH
  try {
    const cchResult = await queryCCHUsage(normalizedUrl, apiKey);
    if (cchResult.success) {
      result.detectedFormat = 'cch';
      return result;
    }
  } catch { /* continue */ }

  // Try OpenAI-compatible billing/models endpoints
  try {
    const openaiResult = await queryOpenAIUsage(normalizedUrl, apiKey);
    if (openaiResult.success) {
      result.detectedFormat = 'openai';
      return result;
    }
  } catch { /* ignore */ }

  return result;
}

/**
 * Query usage from a site. Will try the cached format first, or auto-detect.
 */
async function queryUsageByFormat(format, baseUrl, apiKey) {
  if (format === 'cch') {
    const result = await queryCCHUsage(baseUrl, apiKey);
    if (result.success) return { success: true, format: 'cch', data: result.data, debugSteps: result.debugSteps || [] };
    return { success: false, errorType: result.errorType, message: result.message, debugSteps: result.debugSteps || [] };
  }

  if (format === 'one-api') {
    const result = await queryOneApiUsage(baseUrl, apiKey);
    if (result.success) return { success: true, format: 'one-api', data: result.data, debugSteps: result.debugSteps || [] };
    return { success: false, errorType: result.errorType, message: result.message, debugSteps: result.debugSteps || [] };
  }

  if (format === 'openai') {
    const result = await queryOpenAIUsage(baseUrl, apiKey);
    if (result.success) return { success: true, format: 'openai', data: result.data, debugSteps: result.debugSteps || [] };
    return { success: false, errorType: result.errorType, message: result.message, debugSteps: result.debugSteps || [] };
  }

  if (format === 'new-api' || format === 'sub2api') {
    const endpointMap = {
      'new-api': `${baseUrl}/api/usage/token`,
      sub2api: `${baseUrl}/v1/usage`,
    };
    const result = await tryEndpoint(endpointMap[format], apiKey);
    if (result.success) {
      return {
        success: true,
        format: detectFormatFromData(result.data) || format,
        data: result.data,
        debugSteps: [
          createDebugStep({
            format,
            endpoint: endpointMap[format],
            method: 'GET',
            status: 'success',
            message: `${format} 端点查询成功`,
          }),
        ],
      };
    }
    return {
      success: false,
      errorType: result.errorType,
      message: result.message,
      debugSteps: [
        createDebugStep({
          format,
          endpoint: endpointMap[format],
          method: 'GET',
          status: 'error',
          errorType: result.errorType,
          message: result.message,
        }),
      ],
    };
  }

  return { success: false, errorType: ErrorType.FORMAT, message: `未知格式: ${format}` };
}

async function queryFallbackUsageFormats(baseUrl, apiKey, skipFormats = []) {
  const skipped = new Set(skipFormats);
  const getChecks = getUsageEndpointChecks(baseUrl).filter((check) => !skipped.has(check.format));
  let gatheredErrors = [];
  const debugSteps = [];

  if (getChecks.length > 0) {
    const probes = await Promise.all(
      getChecks.map(async (check) => ({
        format: check.format,
        result: await tryEndpoint(check.url, apiKey),
      })),
    );

    probes.forEach((probe, index) => {
      appendDebugSteps(debugSteps, [
        createDebugStep({
          format: probe.format,
          endpoint: getChecks[index].url,
          method: 'GET',
          status: probe.result.success ? 'success' : 'error',
          errorType: probe.result.success ? null : probe.result.errorType,
          message: probe.result.success
            ? `${probe.format} 端点查询成功`
            : probe.result.message,
        }),
      ]);
    });

    const successful = pickSuccessfulUsageProbe(probes);
    if (successful) return { ...successful, debugSteps };
    gatheredErrors = gatheredErrors.concat(probes.map((probe) => probe.result).filter(Boolean));
  }

  if (!skipped.has('cch')) {
    const cchResult = await queryCCHUsage(baseUrl, apiKey);
    appendDebugSteps(debugSteps, cchResult.debugSteps || []);
    if (cchResult.success) return { success: true, format: 'cch', data: cchResult.data, debugSteps };
    gatheredErrors.push(cchResult);
  }

  if (!skipped.has('openai')) {
    const openaiResult = await queryOpenAIUsage(baseUrl, apiKey);
    appendDebugSteps(debugSteps, openaiResult.debugSteps || []);
    if (openaiResult.success) return { success: true, format: 'openai', data: openaiResult.data, debugSteps };
    gatheredErrors.push(openaiResult);
  }

  return {
    success: false,
    error: mergeRelevantErrors(gatheredErrors),
    debugSteps,
  };
}

async function performUsageQuery(site) {
  const baseUrl = normalizeUrl(site.baseUrl);
  const apiKey = site.apiKey;
  const cachedFormat = site.detectedFormat || null;

  let primaryError = null;
  const debugSteps = [];
  if (cachedFormat) {
    const directResult = await queryUsageByFormat(cachedFormat, baseUrl, apiKey);
    appendDebugSteps(debugSteps, directResult.debugSteps || []);
    if (directResult.success) {
      const { debugSteps: directDebug, ...rest } = directResult;
      return { ...rest, debug: debugSteps };
    }
    primaryError = directResult;
  }

  const fallbackResult = await queryFallbackUsageFormats(baseUrl, apiKey, cachedFormat ? [cachedFormat] : []);
  appendDebugSteps(debugSteps, fallbackResult.debugSteps || []);
  if (fallbackResult.success) {
    const { debugSteps: _ds, ...rest } = fallbackResult;
    return { ...rest, debug: debugSteps };
  }

  const bestError = mergeRelevantErrors(primaryError, fallbackResult.error);
  if (bestError && bestError.errorType !== ErrorType.FORMAT) {
    return {
      success: false,
      error: bestError.message,
      errorType: bestError.errorType,
      debug: debugSteps,
    };
  }

  return {
    success: false,
    error: '无法识别 API 格式，所有格式均无法获取数据',
    errorType: ErrorType.FORMAT,
    debug: debugSteps,
  };
}

async function queryUsage(site) {
  const cacheKey = getUsageQueryKey(site);
  const cached = getCachedUsageQuery(cacheKey);
  if (cached) return cached;

  const inflight = inflightUsageQueries.get(cacheKey);
  if (inflight) return inflight;

  const task = (async () => {
    const result = await performUsageQuery(site);
    if (result && result.success) {
      setCachedUsageQuery(cacheKey, result);
    }
    return result;
  })();

  inflightUsageQueries.set(cacheKey, task);
  try {
    const result = await task;
    return result;
  } catch (err) {
    // Re-throw after cleanup so callers still see the error
    throw err;
  } finally {
    // Always clean up inflight entry, whether resolved or rejected
    if (inflightUsageQueries.get(cacheKey) === task) {
      inflightUsageQueries.delete(cacheKey);
    }
  }
}

/**
 * Query available models from a site via GET /v1/models.
 * Reuses tryEndpoint for consistent error handling (content-type, auth, CF challenge).
 */
async function queryModels(site) {
  const baseUrl = normalizeUrl(site.baseUrl);
  const url = `${baseUrl}/v1/models`;
  const result = await tryEndpoint(url, site.apiKey);
  if (!result.success) {
    return { success: false, error: result.message };
  }
  return { success: true, data: result.data };
}

/**
 * Make a POST fetch request with timeout.
 * Similar to fetchWithTimeout but for POST with JSON body.
 */
async function fetchPostWithTimeout(url, headers, body, timeoutMs = POST_QUERY_TIMEOUT_MS) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json, text/plain, */*',
        ...headers,
      },
      body: JSON.stringify(body),
      credentials: 'include',
      signal: controller.signal,
    });
    clearTimeout(timer);

    // If CF challenge, retry via tab
    if (isCfChallenge(response)) {
      try {
        return await fetchViaTabWithFallback(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...headers },
          body,
          timeoutMs,
        });
      } catch {
        // Tab approach failed, return the original CF response
        return { response, error: null };
      }
    }

    return { response, error: null };
  } catch (error) {
    clearTimeout(timer);
    return { response: null, error };
  }
}

/**
 * Send a chat completion test: POST /v1/chat/completions with "Hi".
 * Auto-selects a model from /v1/models if not specified.
 */
async function chatTest(site, preferredModel) {
  const baseUrl = normalizeUrl(site.baseUrl);
  const apiKey = site.apiKey;
  const headers = { Authorization: `Bearer ${apiKey}` };

  // Step 1: Determine the model to use
  let modelId = preferredModel || null;
  if (!modelId) {
    const modelsResult = await tryEndpoint(`${baseUrl}/v1/models`, apiKey);
    if (modelsResult.success) {
      let models = [];
      if (Array.isArray(modelsResult.data)) {
        models = modelsResult.data;
      } else if (modelsResult.data && Array.isArray(modelsResult.data.data)) {
        models = modelsResult.data.data;
      }

      if (models.length > 0) {
        // Prefer common chat models
        const preferPatterns = [
          /^gpt-4o-mini$/i,
          /^gpt-3\.5-turbo$/i,
          /^gpt-4o$/i,
          /^gpt-4$/i,
          /^claude-3-haiku/i,
          /^claude-3\.5-haiku/i,
          /^deepseek-chat$/i,
          /^gemini.*flash/i,
        ];
        const ids = models.map((m) => m.id || m.name || '');
        for (const pattern of preferPatterns) {
          const match = ids.find((id) => pattern.test(id));
          if (match) { modelId = match; break; }
        }
        // Fallback to first model
        if (!modelId) modelId = ids[0] || 'gpt-3.5-turbo';
      }
    }
    // If models endpoint failed, use a common default
    if (!modelId) modelId = 'gpt-3.5-turbo';
  }

  // Step 2: Send chat completion
  const chatUrl = `${baseUrl}/v1/chat/completions`;
  const chatBody = {
    model: modelId,
    messages: [{ role: 'user', content: 'Hi' }],
    max_tokens: 100,
  };

  const startTime = Date.now();
  const { response, error } = await fetchPostWithTimeout(chatUrl, headers, chatBody);
  const elapsed = Date.now() - startTime;

  if (error) {
    const errorType = classifyError(error, null);
    return {
      success: false,
      model: modelId,
      elapsed,
      error: errorType === ErrorType.TIMEOUT
        ? '请求超时，请检查网络或站点是否可达'
        : `网络错误: ${error.message}`,
    };
  }

  if (!response.ok) {
    const errorType = classifyError(null, response);
    let message;
    switch (errorType) {
      case ErrorType.AUTH:
        message = `认证失败 (${response.status})，请检查 API Key`;
        break;
      case ErrorType.CHALLENGE:
        message = 'Cloudflare 机检未通过，请先在浏览器中打开该站点';
        break;
      default:
        try {
          const errBody = await response.text();
          message = `HTTP ${response.status}: ${errBody.slice(0, 200)}`;
        } catch {
          message = `HTTP ${response.status}: ${response.statusText}`;
        }
    }
    return { success: false, model: modelId, elapsed, error: message };
  }

  try {
    const data = await response.json();
    const choice = data.choices && data.choices[0];
    const content = choice
      ? (choice.message && choice.message.content) || (choice.delta && choice.delta.content) || ''
      : '';
    return {
      success: true,
      model: modelId,
      elapsed,
      content: content.trim(),
      usage: data.usage || null,
      raw: data,
    };
  } catch {
    return {
      success: false,
      model: modelId,
      elapsed,
      error: 'JSON 解析失败',
    };
  }
}

// Listen for messages from the popup
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.action === 'queryUsage') {
    queryUsage(message.site)
      .then((result) => { sendResponse(result); })
      .catch((err) => {
        sendResponse({
          success: false, error: `未知错误: ${err.message}`, errorType: ErrorType.UNKNOWN,
        });
      });
    return true;
  }

  if (message.action === 'queryModels') {
    queryModels(message.site)
      .then((result) => { sendResponse(result); })
      .catch((err) => {
        sendResponse({ success: false, error: `未知错误: ${err.message}` });
      });
    return true;
  }

  if (message.action === 'chatTest') {
    chatTest(message.site, message.model)
      .then((result) => { sendResponse(result); })
      .catch((err) => {
        sendResponse({ success: false, error: `未知错误: ${err.message}` });
      });
    return true;
  }

  if (message.action === 'healthCheck') {
    healthCheck(normalizeUrl(message.baseUrl))
      .then((result) => { sendResponse(result); })
      .catch((err) => {
        sendResponse({ alive: false, error: err.message });
      });
    return true;
  }

  if (message.action === 'detectFormat') {
    detectApiFormat(message.baseUrl, message.apiKey)
      .then((result) => { sendResponse(result); })
      .catch((err) => {
        sendResponse({ alive: false, error: err.message });
      });
    return true;
  }
});
