/**
 * AI API Toolkit — Feature Logic
 * Site CRUD, import/export, batch, drag-and-drop, theme, query, modals.
 * Depends on: utils.js, render.js, popup.js (state + DOM refs)
 */

function showToast(message, type = 'success', duration = 1500) {
  clearTimeout(_toastTimer);
  toastEl.textContent = message;
  toastEl.className = 'toast' + (type !== 'success' ? ' toast-' + type : '');
  toastEl.style.display = '';
  _toastTimer = setTimeout(() => {
    toastEl.style.display = 'none';
  }, duration);
}

function normalizeSiteOrder() {
  sites.forEach((site, index) => {
    site.order = index;
  });
}

function pruneTransientState() {
  const validIds = new Set(sites.map((s) => s.id));
  for (const id of Object.keys(queryResults)) {
    if (!validIds.has(id)) delete queryResults[id];
  }
}

function migrateSites(rawSites) {
  const input = Array.isArray(rawSites) ? rawSites : [];
  const seenIds = new Set();
  let changed = false;

  const migrated = input.map((raw, index) => {
    const src = raw && typeof raw === 'object' ? raw : {};
    if (src !== raw) changed = true;

    let id = src.id ? String(src.id) : generateId();
    if (!src.id) changed = true;
    while (seenIds.has(id)) {
      id = generateId();
      changed = true;
    }
    seenIds.add(id);

    const baseUrl = normalizeBaseUrl(src.baseUrl || '');
    if (baseUrl !== (src.baseUrl || '')) changed = true;

    const apiKey = String(src.apiKey || '');
    const notes = String(src.notes || '');
    const manualFormat = src.manualFormat || src.format || '';
    const detectedFormat = src.detectedFormat || manualFormat || null;
    const tags = sanitizeTags(src.tags || []);
    const order = Number.isFinite(src.order) ? Number(src.order) : index;
    if (!Number.isFinite(src.order)) changed = true;
    if (!Array.isArray(src.tags)) changed = true;

    let name = String(src.name || '').trim();
    if (!name) {
      name = deriveSiteName(baseUrl);
      changed = true;
    }

    return {
      id,
      name,
      baseUrl,
      apiKey,
      notes,
      manualFormat,
      detectedFormat,
      tags,
      order,
    };
  });

  migrated.sort((a, b) => a.order - b.order);
  migrated.forEach((site, index) => {
    if (site.order !== index) changed = true;
    site.order = index;
  });

  return { sites: migrated, changed };
}

async function loadSites() {
  const data = await chrome.storage.local.get('sites');
  const migrated = migrateSites(data.sites || []);
  sites = migrated.sites;
  pruneTransientState();
  if (migrated.changed) {
    await chrome.storage.local.set({ sites });
  }
  return sites;
}

async function saveSites() {
  normalizeSiteOrder();
  await chrome.storage.local.set({ sites });
}

function applyTheme(theme) {
  currentTheme = theme === 'light' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', currentTheme);

  // 显示“切换到”的目标主题
  const switchingToLight = currentTheme === 'dark';
  themeLabel.textContent = switchingToLight ? '亮色模式' : '暗色模式';
  themeIconSun.style.display = switchingToLight ? '' : 'none';
  themeIconMoon.style.display = switchingToLight ? 'none' : '';
}

async function loadTheme() {
  const data = await chrome.storage.local.get(THEME_KEY);
  applyTheme(data[THEME_KEY] || 'dark');
}

async function toggleTheme() {
  const next = currentTheme === 'dark' ? 'light' : 'dark';
  applyTheme(next);
  await chrome.storage.local.set({ [THEME_KEY]: next });
}

function openSettingsMenu() {
  settingsMenu.style.display = '';
}

function closeSettingsMenu() {
  settingsMenu.style.display = 'none';
}

function toggleSettingsMenu() {
  if (settingsMenu.style.display === 'none' || !settingsMenu.style.display) {
    openSettingsMenu();
  } else {
    closeSettingsMenu();
  }
}

function saveDraft() {
  const draft = {
    name: siteNameInput.value,
    baseUrl: siteBaseUrlInput.value,
    // 出于安全考虑，不持久化 API Key
    notes: siteNotesInput.value,
    format: siteFormatSelect.value,
    editId: siteEditIdInput.value,
    tags: formTags,
  };
  chrome.storage.local.set({ [DRAFT_KEY]: draft });
}

function clearDraft() {
  chrome.storage.local.remove(DRAFT_KEY);
}

async function restoreDraft() {
  const data = await chrome.storage.local.get(DRAFT_KEY);
  const draft = data[DRAFT_KEY];
  if (!draft) return false;

  if (draft.baseUrl) {
    siteNameInput.value = draft.name || '';
    siteBaseUrlInput.value = draft.baseUrl || '';
    siteNotesInput.value = draft.notes || '';
    siteFormatSelect.value = draft.format || '';
    siteEditIdInput.value = '';
    setFormTags(draft.tags || []);
    modalTitle.textContent = '添加站点';
    return true;
  }
  return false;
}

function enableDraftAutoSave() {
  [siteNameInput, siteBaseUrlInput, siteApiKeyInput, siteNotesInput, siteFormatSelect].forEach((el) => {
    el.addEventListener('input', saveDraft);
    el.addEventListener('change', saveDraft);
  });
}

function parseQuickImport(text) {
  const result = parseApiKeyUrlPair(text);
  if (!result) return null;
  return { url: result.url || '', key: result.key || '' };
}

function handleQuickImport() {
  const result = parseQuickImport(quickImportEl.value);
  if (!result) return;

  if (result.url) siteBaseUrlInput.value = result.url;
  if (result.key) siteApiKeyInput.value = result.key;

  if (!siteNameInput.value && result.url) {
    siteNameInput.value = deriveSiteName(result.url);
  }

  quickImportEl.value = '';
  saveDraft();
}

function inferBaseUrlFromTab(tab) {
  if (!tab || !tab.url) return '';
  try {
    const parsed = new URL(tab.url);
    if (!/^https?:$/.test(parsed.protocol)) return '';
    return parsed.origin;
  } catch {
    return '';
  }
}

function findExistingSiteByBaseUrl(baseUrl) {
  const normalized = normalizeBaseUrlForCompare(baseUrl);
  if (!normalized) return null;
  return sites.find((site) => normalizeBaseUrlForCompare(site.baseUrl) === normalized) || null;
}

function findExistingSiteByApiKey(apiKey) {
  const normalized = String(apiKey || '').trim();
  if (!normalized) return null;
  return sites.find((site) => String(site.apiKey || '').trim() === normalized) || null;
}

async function upsertSite(input, options = {}) {
  const baseUrl = normalizeBaseUrl(input && input.baseUrl);
  const apiKey = String((input && input.apiKey) || '').trim();
  if (!baseUrl || !apiKey) {
    return { changed: false, reason: 'missing-required' };
  }

  const notes = String((input && input.notes) || '').trim();
  const manualFormat = String((input && input.manualFormat) || '').trim();
  const tags = sanitizeTags(input && input.tags);
  const preferredName = String((input && input.name) || '').trim() || deriveSiteName(baseUrl);
  const sourceLabel = options.sourceLabel ? `自动识别于 ${options.sourceLabel}` : '自动识别导入';

  const existingByUrl = findExistingSiteByBaseUrl(baseUrl);
  const existingByKey = findExistingSiteByApiKey(apiKey);
  const existing = existingByUrl || existingByKey;

  if (existing) {
    let changed = false;
    if (!existing.name && preferredName) {
      existing.name = preferredName;
      changed = true;
    }
    if (!existing.baseUrl && baseUrl) {
      existing.baseUrl = baseUrl;
      changed = true;
    }
    if (!existing.apiKey && apiKey) {
      existing.apiKey = apiKey;
      changed = true;
    }
    if (manualFormat && existing.manualFormat !== manualFormat) {
      existing.manualFormat = manualFormat;
      existing.detectedFormat = manualFormat || existing.detectedFormat || null;
      changed = true;
    }

    const mergedNotes = [existing.notes, notes].filter(Boolean).join(existing.notes && notes ? '\n' : '');
    if (mergedNotes && mergedNotes !== existing.notes) {
      existing.notes = mergedNotes;
      changed = true;
    }

    const existingTags = sanitizeTags(existing.tags || []);
    const nextTags = sanitizeTags([...existingTags, ...tags, 'clipboard-auto']);
    if (nextTags.length !== existingTags.length) {
      existing.tags = nextTags;
      changed = true;
    }

    if (changed) {
      await saveSites();
      renderSiteList();
    }

    return { changed, site: existing, reason: changed ? 'updated' : 'duplicate' };
  }

  const nextSite = {
    id: generateId(),
    name: preferredName,
    baseUrl,
    apiKey,
    notes: notes || sourceLabel,
    manualFormat,
    detectedFormat: manualFormat || null,
    tags: sanitizeTags([...tags, 'clipboard-auto']),
    order: sites.length,
  };

  sites.push(nextSite);
  await saveSites();
  renderSiteList();
  return { changed: true, site: nextSite, reason: 'created' };
}

async function querySite(site, options = {}) {
  const { skipInitialRender = false } = options;
  queryResults[site.id] = { loading: true };
  if (!skipInitialRender) renderSiteList();

  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { action: 'queryUsage', site },
      (response) => {
        if (chrome.runtime.lastError) {
          queryResults[site.id] = {
            success: false,
            error: `扩展通信错误: ${chrome.runtime.lastError.message}`,
          };
        } else if (response && response.success) {
          queryResults[site.id] = response;
          if (response.format && response.format !== site.detectedFormat) {
            site.detectedFormat = response.format;
            saveSites();
          }
        } else {
          queryResults[site.id] = response || {
            success: false,
            error: '未收到响应',
          };
        }
        renderSiteList();
        resolve();
      },
    );
  });
}

async function queryAllSites() {
  if (sites.length === 0) return;

  const concurrency = Math.min(6, Math.max(2, sites.length));
  const queue = [...sites];
  const running = [];

  btnQueryAll.disabled = true;
  try {
    for (const site of queue) {
      queryResults[site.id] = { loading: true };
    }
    renderSiteList();

    while (queue.length > 0 || running.length > 0) {
      while (running.length < concurrency && queue.length > 0) {
        const site = queue.shift();
        const task = querySite(site, { skipInitialRender: true }).then(() => {
          running.splice(running.indexOf(task), 1);
        });
        running.push(task);
      }
      if (running.length > 0) {
        await Promise.race(running);
      }
    }
  } finally {
    btnQueryAll.disabled = false;
  }
}

var _chatTestModelsCache = {};

async function chatTestSite(site, selectedModel) {
  detailTitle.textContent = site.name + ' — API 测试';

  let cancelled = false;

  detailContent.innerHTML = `
    <div class="loading-spinner" style="padding:24px 0;justify-content:center;">
      <div class="spinner"></div> ${selectedModel ? '正在测试模型 ' + escapeHtml(selectedModel) + '…' : '正在测试… (自动选择模型，发送 Hi)'}
      <span id="chatTestTimer" class="chat-test-elapsed" style="margin-left:8px;">0.0s</span>
    </div>
    <div style="text-align:center;padding-bottom:16px;">
      <button id="chatTestCancelBtn" class="btn btn-sm btn-ghost">取消</button>
    </div>
  `;
  detailModal.style.display = '';

  // Elapsed timer
  const timerStart = Date.now();
  const timerEl = document.getElementById('chatTestTimer');
  const timerInterval = setInterval(() => {
    if (timerEl) timerEl.textContent = ((Date.now() - timerStart) / 1000).toFixed(1) + 's';
  }, 100);

  // Fetch models list if not cached for this site
  if (!_chatTestModelsCache[site.id]) {
    try {
      const modelsResp = await new Promise((resolve) => {
        chrome.runtime.sendMessage({ action: 'queryModels', site }, resolve);
      });
      if (modelsResp && modelsResp.success) {
        let models = [];
        if (Array.isArray(modelsResp.data)) {
          models = modelsResp.data;
        } else if (modelsResp.data && Array.isArray(modelsResp.data.data)) {
          models = modelsResp.data.data;
        }
        _chatTestModelsCache[site.id] = models.map((m) => m.id || m.name || '').filter(Boolean).sort((a, b) => a.localeCompare(b));
      }
    } catch { /* ignore, not critical */ }
  }
  const modelsList = _chatTestModelsCache[site.id] || [];

  // Bind cancel button
  const cancelBtn = document.getElementById('chatTestCancelBtn');
  if (cancelBtn) {
    cancelBtn.addEventListener('click', () => {
      cancelled = true;
      clearInterval(timerInterval);
      // Show cancelled state with model picker
      renderChatTestResult(site, {
        success: false,
        model: selectedModel || '(自动)',
        elapsed: Date.now() - timerStart,
        error: '已中断 — 可选择其他模型重新测试',
      }, modelsList);
    });
  }

  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { action: 'chatTest', site, model: selectedModel || undefined },
      (response) => {
        clearInterval(timerInterval);
        if (cancelled) { resolve(); return; }
        if (chrome.runtime.lastError) {
          detailContent.innerHTML = `<div class="error-message"><span>通信错误: ${escapeHtml(chrome.runtime.lastError.message)}</span></div>`;
        } else if (response) {
          renderChatTestResult(site, response, modelsList);
        } else {
          detailContent.innerHTML = `<div class="error-message"><span>未收到响应</span></div>`;
        }
        resolve();
      },
    );
  });
}

function clearDragOverClasses() {
  siteListEl.querySelectorAll('.site-card.drag-over-top, .site-card.drag-over-bottom').forEach((el) => {
    el.classList.remove('drag-over-top', 'drag-over-bottom');
  });
}

function resetDragState() {
  dragState.sourceId = null;
  dragState.targetId = null;
  dragState.placement = null;
  clearDragOverClasses();
  siteListEl.querySelectorAll('.site-card.dragging').forEach((el) => el.classList.remove('dragging'));
}

async function reorderSitesByDrag(sourceId, targetId, placement) {
  const fromIndex = sites.findIndex((s) => s.id === sourceId);
  const targetIndexRaw = sites.findIndex((s) => s.id === targetId);
  if (fromIndex < 0 || targetIndexRaw < 0 || fromIndex === targetIndexRaw) return;

  const [moved] = sites.splice(fromIndex, 1);
  let targetIndex = targetIndexRaw;
  if (fromIndex < targetIndex) targetIndex -= 1;
  if (placement === 'after') targetIndex += 1;

  if (targetIndex < 0) targetIndex = 0;
  if (targetIndex > sites.length) targetIndex = sites.length;

  sites.splice(targetIndex, 0, moved);
  await saveSites();
  renderSiteList();
}

function onSiteListDragStart(e) {
  const target = e.target;
  if (!(target instanceof Element)) return;
  const card = target.closest('.site-card');
  if (!card) return;

  if (!canDragSort()) {
    e.preventDefault();
    return;
  }

  // dragstart e.target is always the [draggable] card, not the child handle.
  // Use lastMouseDownTarget (set by mousedown listener) to check if drag
  // originated from the handle.
  if (!lastMouseDownTarget || !lastMouseDownTarget.closest('.drag-handle')) {
    e.preventDefault();
    return;
  }

  dragState.sourceId = card.dataset.id;
  dragState.targetId = null;
  dragState.placement = null;
  card.classList.add('dragging');

  if (e.dataTransfer) {
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', dragState.sourceId);
  }
}

function onSiteListDragOver(e) {
  if (!dragState.sourceId) return;
  const target = e.target;
  if (!(target instanceof Element)) return;

  const card = target.closest('.site-card');
  if (!card || card.dataset.id === dragState.sourceId) return;

  e.preventDefault();
  clearDragOverClasses();

  const rect = card.getBoundingClientRect();
  const before = e.clientY < rect.top + rect.height / 2;
  card.classList.add(before ? 'drag-over-top' : 'drag-over-bottom');

  dragState.targetId = card.dataset.id;
  dragState.placement = before ? 'before' : 'after';
}

async function onSiteListDrop(e) {
  if (!dragState.sourceId) return;
  e.preventDefault();

  if (dragState.targetId) {
    await reorderSitesByDrag(dragState.sourceId, dragState.targetId, dragState.placement || 'before');
  }
  resetDragState();
}

function onSiteListDragEnd() {
  resetDragState();
}

function exportSites() {
  const payload = {
    schemaVersion: 2,
    exportedAt: new Date().toISOString(),
    sites,
  };

  const json = JSON.stringify(payload, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `ai-api-sites-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  showToast('导出成功');
}

function parseImportPayload(raw) {
  if (Array.isArray(raw)) {
    return raw;
  }
  if (!raw || typeof raw !== 'object') {
    throw new Error('导入文件格式错误');
  }
  if (!Array.isArray(raw.sites)) {
    throw new Error('导入文件缺少 sites 数组');
  }
  return raw.sites;
}

async function loadImportPreviewFromFile() {
  const file = importFileInput.files && importFileInput.files[0];
  if (!file) {
    importPreviewSites = [];
    renderImportPreview([], null);
    return;
  }

  try {
    const text = await file.text();
    const raw = JSON.parse(text);
    const parsed = parseImportPayload(raw);
    const migrated = migrateSites(parsed).sites;
    importPreviewSites = migrated;
    renderImportPreview(migrated, raw);
  } catch (err) {
    importPreviewSites = [];
    renderImportPreview([], null);
    showToast(`导入文件解析失败: ${err.message}`, 'error');
  }
}

function mergeSitesByBaseUrl(existingSites, importedSites) {
  const merged = existingSites.map((site) => ({ ...site, tags: sanitizeTags(site.tags || []) }));
  const baseMap = new Map();

  merged.forEach((site, index) => {
    baseMap.set(normalizeBaseUrlForCompare(site.baseUrl), index);
  });

  for (const incoming of importedSites) {
    const key = normalizeBaseUrlForCompare(incoming.baseUrl);
    if (!key) continue;

    if (baseMap.has(key)) {
      const idx = baseMap.get(key);
      const prev = merged[idx];
      merged[idx] = {
        ...prev,
        name: incoming.name || prev.name,
        apiKey: incoming.apiKey || prev.apiKey,
        notes: incoming.notes || prev.notes,
        manualFormat: incoming.manualFormat || prev.manualFormat,
        detectedFormat: incoming.detectedFormat || prev.detectedFormat,
        id: prev.id,
        order: prev.order,
        tags: sanitizeTags([...(prev.tags || []), ...(incoming.tags || [])]),
      };
    } else {
      merged.push({ ...incoming, order: merged.length });
      baseMap.set(key, merged.length - 1);
    }
  }

  return merged;
}

async function importSitesFromFile() {
  const mode = importModeSelect.value || 'merge';
  const file = importFileInput.files && importFileInput.files[0];
  if (!file) {
    showToast('请选择 JSON 文件', 'error');
    return;
  }

  let imported;
  try {
    const text = await file.text();
    const raw = JSON.parse(text);
    imported = migrateSites(parseImportPayload(raw)).sites;
  } catch (err) {
    showToast(`导入失败: ${err.message}`, 'error');
    return;
  }

  let nextSites;
  if (mode === 'replace') {
    nextSites = imported.map((site) => ({ ...site }));
  } else if (mode === 'append') {
    const startOrder = sites.length;
    nextSites = [...sites.map((site) => ({ ...site })), ...imported.map((site, i) => ({ ...site, id: generateId(), order: startOrder + i }))];
  } else {
    nextSites = mergeSitesByBaseUrl(sites, imported);
  }

  const migrated = migrateSites(nextSites).sites;
  sites = migrated;
  pruneTransientState();
  await saveSites();
  renderSiteList();
  closeImportModal();
  showToast(`导入完成：${imported.length} 项`);
}

function openImportModal() {
  importModal.style.display = '';
  document.body.classList.add('modal-open');
  importModeSelect.value = 'merge';
  importFileInput.value = '';
  importPreviewSites = [];
  importPreview.style.display = 'none';
  importPreview.innerHTML = '';
  btnDoImport.disabled = true;
}

function closeImportModal() {
  importModal.style.display = 'none';
  document.body.classList.remove('modal-open');
}

function parseBatchImportLines(text, commonTags = []) {
  const lines = String(text || '').split(/\n/);
  const parsed = [];
  let invalidCount = 0;

  for (const lineRaw of lines) {
    const line = lineRaw.trim();
    if (!line) continue;

    const match = line.match(/^(https?:\/\/\S+)\s+(\S+)(?:\s+(.+))?$/i);
    if (!match) {
      invalidCount += 1;
      continue;
    }

    const baseUrl = normalizeBaseUrl(match[1]);
    const apiKey = match[2].trim();
    const name = (match[3] || '').trim() || deriveSiteName(baseUrl);

    parsed.push({
      id: generateId(),
      name,
      baseUrl,
      apiKey,
      notes: '',
      manualFormat: '',
      detectedFormat: null,
      tags: sanitizeTags(commonTags),
      order: 0,
    });
  }

  return { parsed, invalidCount };
}

async function doBatchImport() {
  if (batchParsedSites.length === 0) {
    showToast('没有可导入内容', 'error');
    return;
  }

  const startOrder = sites.length;
  const incoming = batchParsedSites.map((site, idx) => ({ ...site, order: startOrder + idx }));
  sites = [...sites, ...incoming];
  sites = migrateSites(sites).sites;
  await saveSites();
  renderSiteList();
  closeBatchModal();
  showToast(`批量导入完成：${incoming.length} 项`);
}

function openBatchModal() {
  batchModal.style.display = '';
  document.body.classList.add('modal-open');
  batchInput.value = '';
  batchTagsInput.value = '';
  batchParsedSites = [];
  batchPreview.style.display = 'none';
  batchPreview.innerHTML = '';
  btnDoBatch.disabled = true;
}

function closeBatchModal() {
  batchModal.style.display = 'none';
  document.body.classList.remove('modal-open');
}

function openAddModal() {
  modalTitle.textContent = '添加站点';
  siteForm.reset();
  siteEditIdInput.value = '';
  siteNotesInput.value = '';
  quickImportEl.value = '';
  quickImportGroup.style.display = '';
  siteApiKeyInput.type = 'password';
  iconEye.style.display = 'none';
  iconEyeOff.style.display = '';
  formTags = [];
  renderFormTags();
  siteHealthStatus.style.display = 'none';
  siteHealthStatus.innerHTML = '';
  formatDetectStatus.textContent = '';
  siteModal.style.display = '';
  document.body.classList.add('modal-open');

  // Restore draft AFTER showing modal (saveDraft not triggered)
  restoreDraft().then((hasDraft) => {
    if (hasDraft) {
      if (!siteBaseUrlInput.value) siteBaseUrlInput.focus();
      else if (!siteApiKeyInput.value) siteApiKeyInput.focus();
      else siteNameInput.focus();
    } else {
      quickImportEl.focus();
    }
  });
}

function openEditModal(site) {
  modalTitle.textContent = '编辑站点';
  siteNameInput.value = site.name;
  siteBaseUrlInput.value = site.baseUrl;
  siteApiKeyInput.value = site.apiKey;
  siteNotesInput.value = site.notes || '';
  siteFormatSelect.value = site.manualFormat || '';
  siteEditIdInput.value = site.id;
  setFormTags(site.tags || []);
  quickImportEl.value = '';
  quickImportGroup.style.display = 'none';
  siteApiKeyInput.type = 'password';
  iconEye.style.display = 'none';
  iconEyeOff.style.display = '';
  siteHealthStatus.style.display = 'none';
  siteHealthStatus.innerHTML = '';
  formatDetectStatus.textContent = site.detectedFormat ? '— 当前: ' + site.detectedFormat : '';
  siteModal.style.display = '';
  document.body.classList.add('modal-open');
  siteNameInput.focus();
}

function closeModal() {
  siteModal.style.display = 'none';
  document.body.classList.remove('modal-open');
  hideTagsAutocomplete();
}

async function handleSiteFormSubmit(e) {
  e.preventDefault();

  if (quickImportEl.value.trim()) {
    handleQuickImport();
  }

  const name = siteNameInput.value.trim();
  const baseUrl = normalizeBaseUrl(siteBaseUrlInput.value.trim());
  const apiKey = siteApiKeyInput.value.trim();
  const notes = siteNotesInput.value.trim();
  const manualFormat = siteFormatSelect.value || '';
  const editId = siteEditIdInput.value;
  const tags = sanitizeTags(formTags);

  if (!baseUrl || !apiKey) return;

  try {
    const parsed = new URL(baseUrl);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      alert('Base URL 必须以 http:// 或 https:// 开头');
      siteBaseUrlInput.focus();
      return;
    }
  } catch {
    alert('请输入有效的 URL（例如 https://api.example.com）');
    siteBaseUrlInput.focus();
    return;
  }

  const finalName = name || deriveSiteName(baseUrl);

  if (editId) {
    const idx = sites.findIndex((s) => s.id === editId);
    if (idx >= 0) {
      sites[idx].name = finalName;
      sites[idx].baseUrl = baseUrl;
      sites[idx].apiKey = apiKey;
      sites[idx].notes = notes;
      sites[idx].manualFormat = manualFormat;
      sites[idx].detectedFormat = manualFormat || sites[idx].detectedFormat || null;
      sites[idx].tags = tags;
    }
  } else {
    sites.push({
      id: generateId(),
      name: finalName,
      baseUrl,
      apiKey,
      notes,
      manualFormat,
      detectedFormat: manualFormat || null,
      tags,
      order: sites.length,
    });
  }

  await saveSites();
  clearDraft();
  renderSiteList();
  closeModal();
}

async function deleteSite(id) {
  sites = sites.filter((s) => s.id !== id);
  delete queryResults[id];
  await saveSites();
  renderSiteList();
}

function toggleKeyVisibility() {
  if (siteApiKeyInput.type === 'password') {
    siteApiKeyInput.type = 'text';
    iconEye.style.display = '';
    iconEyeOff.style.display = 'none';
  } else {
    siteApiKeyInput.type = 'password';
    iconEye.style.display = 'none';
    iconEyeOff.style.display = '';
  }
}

function openBackendPanel(baseUrl) {
  const url = normalizeBaseUrl(baseUrl);
  if (!url) return;

  try {
    const parsed = new URL(url);
    const origin = parsed.origin;

    // Open a dropdown menu with common backend paths
    const existing = document.querySelector('.backend-dropdown');
    if (existing) existing.remove();

    const dropdown = document.createElement('div');
    dropdown.className = 'backend-dropdown';
    dropdown.style.position = 'fixed';
    dropdown.style.zIndex = '999';
    dropdown.style.bottom = 'auto';

    dropdown.innerHTML = BACKEND_PATHS.map((path) => {
      const fullUrl = origin + path;
      return `<button class="backend-dropdown-item" data-url="${escapeHtml(fullUrl)}">${escapeHtml(path || '/')}</button>`;
    }).join('');

    // Position near the button
    const anchor = document.activeElement ?? document.body;
    const rect = anchor.getBoundingClientRect();
    dropdown.style.top = (rect.bottom + 4) + 'px';
    dropdown.style.left = Math.max(8, rect.left - 60) + 'px';

    document.body.appendChild(dropdown);

    dropdown.addEventListener('click', (e) => {
      const item = e.target.closest('.backend-dropdown-item');
      if (item && item.dataset.url) {
        chrome.tabs.create({ url: item.dataset.url });
        dropdown.remove();
      }
    });
  } catch {
    showToast('URL 格式无效', 'error');
  }
}

function detectSiteFormatAndHealth(baseUrl, apiKey) {
  const url = normalizeBaseUrl(baseUrl);
  if (!url) return;

  formatDetectStatus.textContent = '— 检测中...';
  siteHealthStatus.style.display = '';
  siteHealthStatus.className = 'site-health-status health-loading';
  siteHealthStatus.innerHTML = '<span class="health-dot checking"></span> 正在检测站点状态和 API 格式...';

  chrome.runtime.sendMessage(
    { action: 'detectFormat', baseUrl: url, apiKey: apiKey || '' },
    (response) => {
      if (chrome.runtime.lastError) {
        siteHealthStatus.className = 'site-health-status health-error';
        siteHealthStatus.innerHTML = '<span class="health-dot dead"></span> 检测失败: ' + escapeHtml(chrome.runtime.lastError.message);
        formatDetectStatus.textContent = '';
        return;
      }

      if (response && response.alive) {
        siteHealthStatus.className = 'site-health-status health-ok';
        let statusHtml = '<span class="health-dot alive"></span> 站点存活';
        if (response.latency) {
          statusHtml += ' <span class="text-muted" style="font-size:11px;">(' + response.latency + 'ms)</span>';
        }
        if (response.detectedFormat) {
          statusHtml += ' · 检测到格式: <strong>' + escapeHtml(response.detectedFormat) + '</strong>';
          // Auto-fill the format selector
          if (siteFormatSelect.querySelector(`option[value="${response.detectedFormat}"]`)) {
            siteFormatSelect.value = response.detectedFormat;
          }
          formatDetectStatus.textContent = '— 已检测: ' + response.detectedFormat;
        } else {
          formatDetectStatus.textContent = '— 未识别格式';
        }
        if (response.serverInfo) {
          statusHtml += '<br><span class="text-muted" style="font-size:10px;">' + escapeHtml(response.serverInfo) + '</span>';
        }
        siteHealthStatus.innerHTML = statusHtml;
      } else {
        siteHealthStatus.className = 'site-health-status health-error';
        siteHealthStatus.innerHTML = '<span class="health-dot dead"></span> 站点不可达' +
          (response && response.error ? ': ' + escapeHtml(response.error) : '');
        formatDetectStatus.textContent = '— 站点不可达';
      }
    }
  );
}

function checkSiteHealth(site) {
  const card = siteListEl.querySelector(`.site-card[data-id="${site.id}"]`);
  if (!card) return;

  const dot = card.querySelector('.site-status-dot');
  if (dot) {
    dot.className = 'site-status-dot checking';
    dot.title = '正在检测...';
  }

  chrome.runtime.sendMessage(
    { action: 'healthCheck', baseUrl: site.baseUrl },
    (response) => {
      if (!dot) return;
      if (chrome.runtime.lastError || !response) {
        dot.className = 'site-status-dot dead';
        dot.title = '不可达';
        return;
      }
      if (response.alive) {
        dot.className = 'site-status-dot alive';
        dot.title = '存活 (' + (response.latency || '?') + 'ms)';
      } else {
        dot.className = 'site-status-dot dead';
        dot.title = '不可达: ' + (response.error || '未知错误');
      }
    }
  );
}

function persistQueryResults() {
  clearTimeout(_persistTimer);
  _persistTimer = setTimeout(() => {
    const persistable = {};
    for (const [id, result] of Object.entries(queryResults)) {
      if (!result.loading) persistable[id] = result;
    }
    chrome.storage.local.set({ queryResults: persistable });
  }, 400);
}

function flushQueryResultsNow() {
  clearTimeout(_persistTimer);
  const persistable = {};
  for (const [id, result] of Object.entries(queryResults)) {
    if (!result.loading) persistable[id] = result;
  }
  chrome.storage.local.set({ queryResults: persistable });
}

/**
 * 批量导出所有站点到 CC-Switch
 * 逐个通过 Deep Link 发送，间隔 500ms 避免冲突
 */
async function exportAllToCCS() {
  if (sites.length === 0) {
    showToast('没有站点可导出', 'warning');
    return;
  }

  const importTarget = await openCCSImportChooser(`将把 ${sites.length} 个站点导入到 CC-Switch。请选择本次导入目标。`);
  if (!importTarget) return;
  const targetLabel = getCCSImportTargetLabel(importTarget);

  const confirmed = confirm(
    `即将把 ${sites.length} 个站点导入到 CC-Switch → ${targetLabel}。\n` +
    `所有站点都会按 ${targetLabel} 的导入规则生成 endpoint。\n\n` +
    `请确保 CC-Switch 已安装并正在运行。`
  );
  if (!confirmed) return;

  let successCount = 0;
  let failCount = 0;

  for (let i = 0; i < sites.length; i++) {
    const site = sites[i];
    const deepLink = buildCCSDeepLink(site, importTarget);

    try {
      await new Promise((resolve, reject) => {
        chrome.tabs.create({ url: deepLink, active: false }, (tab) => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            successCount++;
            // 自动关闭中转 tab
            setTimeout(() => {
              try { chrome.tabs.remove(tab.id); } catch {}
            }, 2000);
            resolve();
          }
        });
      });
      showToast(`(${i + 1}/${sites.length}) ${site.name} → ${targetLabel} ✓`, 'success');
    } catch (err) {
      failCount++;
      showToast(`${site.name} 导入失败: ${err.message}`, 'error');
    }

    // 间隔 600ms 避免 Deep Link 冲突
    if (i < sites.length - 1) {
      await new Promise(r => setTimeout(r, 600));
    }
  }

  showToast(`导出完成: ${successCount} 成功, ${failCount} 失败`, successCount > 0 ? 'success' : 'error');
}
