/**
 * AI API Toolkit — Main Entry
 * State, DOM references, event binding, init.
 * Loaded last; init() runs on DOMContentLoaded after all scripts.
 * Uses var for shared state (accessible across script files).
 */

// ============================================
// State (var for cross-script access)
// ============================================

var sites = [];
var queryResults = {};

var activeTagFilters = new Set();
var formTags = [];
var batchParsedSites = [];
var importPreviewSites = [];
var detectedKeys = [];

var _persistTimer = null;
var _toastTimer = null;
var currentTheme = 'dark';
var sitesLoaded = false;
var lastClipboardSignature = '';
var clipboardPollTimer = null;
var clipboardStatusTimer = null;
var clipboardAutoDetectPaused = false;

var dragState = {
  sourceId: null,
  targetId: null,
  placement: null,
};

var lastMouseDownTarget = null;

// ============================================
// DOM References (var for cross-script access)
// ============================================

var siteListEl = document.getElementById('siteList');
var emptyStateEl = document.getElementById('emptyState');
var btnAddSite = document.getElementById('btnAddSite');
var btnQueryAll = document.getElementById('btnQueryAll');
var searchBar = document.getElementById('searchBar');
var searchInput = document.getElementById('searchInput');
var tagFilterBar = document.getElementById('tagFilterBar');
var btnSettings = document.getElementById('btnSettings');
var settingsMenu = document.getElementById('settingsMenu');
var btnBatchImport = document.getElementById('btnBatchImport');
var btnExport = document.getElementById('btnExport');
var btnImport = document.getElementById('btnImport');
var btnToggleTheme = document.getElementById('btnToggleTheme');
var themeIconSun = document.getElementById('themeIconSun');
var themeIconMoon = document.getElementById('themeIconMoon');
var themeLabel = document.getElementById('themeLabel');
var siteModal = document.getElementById('siteModal');
var modalTitle = document.getElementById('modalTitle');
var siteForm = document.getElementById('siteForm');
var siteNameInput = document.getElementById('siteName');
var siteBaseUrlInput = document.getElementById('siteBaseUrl');
var siteApiKeyInput = document.getElementById('siteApiKey');
var siteFormatSelect = document.getElementById('siteFormat');
var siteEditIdInput = document.getElementById('siteEditId');
var btnCloseModal = document.getElementById('btnCloseModal');
var btnCancelModal = document.getElementById('btnCancelModal');
var btnToggleKey = document.getElementById('btnToggleKey');
var iconEye = document.getElementById('iconEye');
var iconEyeOff = document.getElementById('iconEyeOff');
var quickImportEl = document.getElementById('quickImport');
var quickImportGroup = document.getElementById('quickImportGroup');
var siteNotesInput = document.getElementById('siteNotes');
var siteTagsContainer = document.getElementById('siteTagsContainer');
var siteTagsInput = document.getElementById('siteTags');
var tagsAutocomplete = document.getElementById('tagsAutocomplete');
var batchModal = document.getElementById('batchModal');
var btnCloseBatch = document.getElementById('btnCloseBatch');
var btnCancelBatch = document.getElementById('btnCancelBatch');
var btnDoBatch = document.getElementById('btnDoBatch');
var batchInput = document.getElementById('batchInput');
var batchTagsInput = document.getElementById('batchTags');
var batchPreview = document.getElementById('batchPreview');
var importModal = document.getElementById('importModal');
var btnCloseImport = document.getElementById('btnCloseImport');
var btnCancelImport = document.getElementById('btnCancelImport');
var btnDoImport = document.getElementById('btnDoImport');
var importModeSelect = document.getElementById('importMode');
var importFileInput = document.getElementById('importFile');
var importPreview = document.getElementById('importPreview');
var detailModal = document.getElementById('detailModal');
var detailTitle = document.getElementById('detailTitle');
var detailContent = document.getElementById('detailContent');
var btnCloseDetail = document.getElementById('btnCloseDetail');
var toastEl = document.getElementById('toast');
var btnDetect = document.getElementById('btnDetect');
var detectedBanner = document.getElementById('detectedBanner');
var btnOpenUrl = document.getElementById('btnOpenUrl');
var btnOpenBackend = document.getElementById('btnOpenBackend');
var btnDetectFormat = document.getElementById('btnDetectFormat');
var formatDetectStatus = document.getElementById('formatDetectStatus');
var siteHealthStatus = document.getElementById('siteHealthStatus');
var btnExportCCS = document.getElementById('btnExportCCS');
var ccsChooserModal = document.getElementById('ccsChooserModal');
var ccsChooserTitle = document.getElementById('ccsChooserTitle');
var ccsChooserText = document.getElementById('ccsChooserText');
var btnCloseCCSChooser = document.getElementById('btnCloseCCSChooser');
var btnCancelCCSChooser = document.getElementById('btnCancelCCSChooser');
var btnChooseCCSCodex = document.getElementById('btnChooseCCSCodex');
var btnChooseCCSClaude = document.getElementById('btnChooseCCSClaude');
var pendingCCSImportChoiceResolver = null;

// Verify critical DOM references
const criticalElements = { siteListEl, btnAddSite, btnQueryAll, searchInput, siteModal, siteForm };
Object.entries(criticalElements).forEach(([name, el]) => {
  if (!el) console.warn(`[AI API Toolkit] Critical DOM element not found: ${name}. Some features may not work.`);
});

async function getActiveHttpTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs && tabs[0];
  if (!tab || !tab.url) return null;
  if (!/^https?:/i.test(tab.url)) return null;
  return tab;
}

function setClipboardStatus(message, tone) {
  document.body.dataset.clipboardTone = tone || '';
  if (!message) {
    document.body.removeAttribute('data-clipboard-status');
    document.body.removeAttribute('data-clipboard-tone');
    return;
  }
  document.body.setAttribute('data-clipboard-status', message);
  clearTimeout(clipboardStatusTimer);
  clipboardStatusTimer = setTimeout(() => {
    document.body.removeAttribute('data-clipboard-status');
    document.body.removeAttribute('data-clipboard-tone');
  }, 3200);
}

function pauseClipboardAutoDetect() {
  clipboardAutoDetectPaused = true;
  stopClipboardAutoDetect();
}

async function detectClipboardApiKey(options = {}) {
  if (!sitesLoaded) {
    return { status: 'sites-not-ready' };
  }

  if (!navigator.clipboard || typeof navigator.clipboard.readText !== 'function') {
    return { status: 'unsupported' };
  }

  if (clipboardAutoDetectPaused && !options.force) {
    return { status: 'paused' };
  }

  try {
    const text = await navigator.clipboard.readText();
    const parsed = parseApiKeyUrlPair(text);
    if (!parsed || !parsed.key) return { status: 'empty' };

    const signature = parsed.key + '|' + (parsed.url || '');
    if (!options.force && signature === lastClipboardSignature) {
      return { status: 'duplicate-scan' };
    }
    lastClipboardSignature = signature;

    let baseUrl = parsed.url || '';
    let sourceLabel = '剪贴板';
    if (!baseUrl) {
      const activeTab = await getActiveHttpTab();
      baseUrl = inferBaseUrlFromTab(activeTab);
      if (baseUrl) {
        sourceLabel = '剪贴板 + 当前标签页';
      }
    }

    if (!baseUrl) {
      setClipboardStatus(`剪贴板识别到 ${maskApiKey(parsed.key)}，缺少 URL，未自动添加`, 'warning');
      return { status: 'missing-url', key: parsed.key };
    }

    let result;
    try {
      result = await upsertSite({
      baseUrl,
      apiKey: parsed.key,
      notes: '来源：剪贴板自动识别',
      tags: ['clipboard'],
    }, { sourceLabel });
    } catch (e) { console.error('upsertSite failed:', e); return { status: 'error', error: e }; }

    if (result && result.site) {
      pauseClipboardAutoDetect();
    }

    if (result.reason === 'created') {
      showToast(`已从剪贴板自动添加 ${deriveSiteName(baseUrl)}`);
      setClipboardStatus(`已自动添加 ${deriveSiteName(baseUrl)} · ${maskApiKey(parsed.key)}，本次暂停继续识别`, 'success');
      return { status: 'created', site: result.site };
    }

    if (result.reason === 'updated') {
      setClipboardStatus(`已更新已存在站点 · ${deriveSiteName(baseUrl)}，本次暂停继续识别`, 'success');
      return { status: 'updated', site: result.site };
    }

    if (result.reason === 'duplicate') {
      setClipboardStatus(`已识别到已存在站点 · ${deriveSiteName(baseUrl)}，本次暂停继续识别`, 'success');
    }
    return { status: 'duplicate', site: result.site };
  } catch (error) {
    const message = String(error?.message ?? '');
    if (/not allowed|denied|permission/i.test(message)) {
      return { status: 'denied' };
    }
    return { status: 'error', error };
  }
}

function startClipboardAutoDetect() {
  stopClipboardAutoDetect();
  clipboardAutoDetectPaused = false;
  detectClipboardApiKey({ force: true }).catch(() => {/* first poll; ignore */});
  clipboardPollTimer = setInterval(() => {
    if (document.hidden) return;
    detectClipboardApiKey();
  }, CLIPBOARD_POLL_MS);
}

function stopClipboardAutoDetect() {
  if (clipboardPollTimer) {
    clearInterval(clipboardPollTimer);
    clipboardPollTimer = null;
  }
}

function detectKeysFromPage() {
  btnDetect.disabled = true;
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs && tabs[0];
    if (!tab || !tab.id || tab.url?.startsWith('chrome://') || tab.url?.startsWith('chrome-extension://')) {
      showToast('无法检测此页面', 'error');
      btnDetect.disabled = false;
      return;
    }
    chrome.scripting.executeScript(
      { target: { tabId: tab.id }, files: ['detector.js'] },
      (results) => {
        btnDetect.disabled = false;
        if (chrome.runtime.lastError) {
          showToast('检测失败: ' + chrome.runtime.lastError.message, 'error');
          return;
        }
        detectedKeys = (results && results[0] && results[0].result) || [];
        renderDetectedBanner(detectedKeys);
        if (detectedKeys.length === 0) {
          showToast('当前页面未检测到 API Key');
        } else {
          showToast('检测到 ' + detectedKeys.length + ' 个 API Key');
        }
      }
    );
  });
}

function addDetectedKey(index, editedUrl) {
  const item = detectedKeys[index];
  if (!item) return;
  const baseUrl = editedUrl || item.inferredBaseUrl || '';
  siteForm.reset();
  siteBaseUrlInput.value = baseUrl;
  siteApiKeyInput.value = item.key || '';
  siteNameInput.value = deriveSiteName(baseUrl);
  siteEditIdInput.value = '';
  siteNotesInput.value = '';
  siteFormatSelect.value = '';
  setFormTags([]);
  quickImportEl.value = '';
  quickImportGroup.style.display = '';
  siteApiKeyInput.type = 'password';
  iconEye.style.display = 'none';
  iconEyeOff.style.display = '';
  modalTitle.textContent = '添加站点';
  siteModal.style.display = '';
  document.body.classList.add('modal-open');
  siteNameInput.focus();
}

function queryDetectedKey(index, editedUrl, selectedFormat) {
  const item = detectedKeys[index];
  if (!item) return;
  const baseUrl = editedUrl || item.inferredBaseUrl || '';
  if (!baseUrl) {
    showToast('请填写 Base URL', 'error');
    return;
  }

  const tempSite = {
    id: '_detect_' + index,
    name: deriveSiteName(baseUrl),
    baseUrl: baseUrl,
    apiKey: item.key,
    manualFormat: selectedFormat || '',
    detectedFormat: selectedFormat || '',
  };

  // Show loading in detail modal
  detailTitle.textContent = tempSite.name + ' — 额度查询';
  detailContent.innerHTML = `
    <div class="loading-spinner" style="padding:24px 0;justify-content:center;">
      <div class="spinner"></div> 正在查询...
    </div>
  `;
  detailModal.style.display = '';

  chrome.runtime.sendMessage(
    { action: 'queryUsage', site: tempSite },
    (response) => {
      if (chrome.runtime.lastError) {
        detailContent.innerHTML = renderQueryFailureContent(
          { error: `通信错误: ${chrome.runtime.lastError.message}` },
          '查询失败',
        );
        return;
      }
      if (response && response.success) {
        openDetailModal(tempSite, response);
      } else {
        detailContent.innerHTML = renderQueryFailureContent(response || {}, '查询失败');
      }
    }
  );
}

async function handleSiteListClick(e) {
  const target = e.target;
  if (!(target instanceof Element)) return;

  const tagBtn = target.closest('.tag-pill');
  if (tagBtn && tagBtn.dataset.tag) {
    toggleTagFilter(tagBtn.dataset.tag);
    return;
  }

  const btn = target.closest('button');
  if (!btn) return;

  const card = btn.closest('.site-card');
  if (!card) return;

  const id = card.dataset.id;
  const site = sites.find((s) => s.id === id);
  if (!site) return;

  if (btn.classList.contains('btn-query')) {
    querySite(site);
    return;
  }

  if (btn.classList.contains('btn-models')) {
    queryAndShowModels(site);
    return;
  }

  if (btn.classList.contains('btn-chat-test')) {
    chatTestSite(site);
    return;
  }

  if (btn.classList.contains('btn-view-detail')) {
    const result = queryResults[id];
    if (result && result.success) {
      openDetailModal(site, result);
    }
    return;
  }

  if (btn.classList.contains('btn-edit')) {
    openEditModal(site);
    return;
  }

  if (btn.classList.contains('btn-delete')) {
    if (confirm(`确定删除站点「${site.name}」？此操作不可撤销。`)) {
      deleteSite(id);
    }
    return;
  }

  if (btn.classList.contains('btn-copy-url')) {
    try {
      await copyToClipboard(site.baseUrl || '');
      showToast('已复制');
    } catch (err) {
      showToast(`复制失败: ${err.message}`, 'error');
    }
    return;
  }

  if (btn.classList.contains('btn-copy-key')) {
    try {
      await copyToClipboard(site.apiKey || '');
      showToast('已复制 API Key');
    } catch (err) {
      showToast(`复制失败: ${err.message}`, 'error');
    }
    return;
  }

  if (btn.classList.contains('btn-ccs')) {
    const importTarget = await openCCSImportChooser(`站点「${site.name}」准备导入到 CC-Switch。请选择导入目标。`);
    if (!importTarget) return;
    const targetLabel = getCCSImportTargetLabel(importTarget);
    const deepLink = buildCCSDeepLink(site, importTarget);

    // 通过 Deep Link 直接打开 CC-Switch 导入
    chrome.tabs.create({ url: deepLink }, (tab) => {
      if (chrome.runtime.lastError) {
        // Deep Link 失败，fallback 复制链接到剪贴板
        copyToClipboard(deepLink).then(() => {
          showToast(`CC-Switch 未响应，已复制导入链接到剪贴板`, 'warning');
        });
      } else {
        showToast(`正在导入到 CC-Switch → ${targetLabel}...`, 'success');
      }
    });
    return;
  }

  if (btn.classList.contains('btn-open-site')) {
    chrome.tabs.create({ url: site.baseUrl });
    return;
  }

  if (btn.classList.contains('btn-backend')) {
    openBackendPanel(site.baseUrl);
    return;
  }

  if (btn.classList.contains('btn-health-check')) {
    checkSiteHealth(site);
    return;
  }
}

function bindTagInputEvents() {
  siteTagsInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      commitTagsFromInput();
      return;
    }

    if (e.key === 'Tab' && siteTagsInput.value.trim()) {
      e.preventDefault();
      commitTagsFromInput();
      return;
    }

    if (e.key === 'Backspace' && !siteTagsInput.value.trim() && formTags.length > 0) {
      removeFormTag(formTags[formTags.length - 1]);
    }
  });

  siteTagsInput.addEventListener('input', () => {
    // 支持输入逗号后自动切分成 tag token
    const value = siteTagsInput.value;
    if (/[\n,，]/.test(value)) {
      const parts = value.split(/[\n,，]/);
      const complete = parts.slice(0, -1).map((s) => s.trim()).filter(Boolean);
      for (const tag of complete) addFormTag(tag);
      siteTagsInput.value = parts[parts.length - 1] || '';
    }

    if (siteTagsInput.value.trim()) {
      renderTagsAutocomplete();
    } else {
      hideTagsAutocomplete();
    }
    saveDraft();
  });

  siteTagsInput.addEventListener('blur', () => {
    setTimeout(() => {
      if (siteTagsInput.value.trim()) {
        commitTagsFromInput();
      }
      hideTagsAutocomplete();
    }, 120);
  });

  siteTagsContainer.addEventListener('click', (e) => {
    const target = e.target;
    if (!(target instanceof Element)) return;
    const removeBtn = target.closest('.tag-chip-remove');
    if (!removeBtn || !removeBtn.dataset.tag) return;
    removeFormTag(removeBtn.dataset.tag);
  });

  tagsAutocomplete.addEventListener('mousedown', (e) => {
    const target = e.target;
    if (!(target instanceof Element)) return;
    const item = target.closest('.tags-autocomplete-item');
    if (!item || !item.dataset.tag) return;
    e.preventDefault();
    addFormTag(item.dataset.tag);
    siteTagsInput.value = '';
    hideTagsAutocomplete();
    siteTagsInput.focus();
  });
}

function bindModalEvents() {
  siteModal.addEventListener('click', (e) => {
    if (e.target === siteModal) closeModal();
  });

  detailModal.addEventListener('click', (e) => {
    if (e.target === detailModal) closeDetailModal();
  });

  batchModal.addEventListener('click', (e) => {
    if (e.target === batchModal) closeBatchModal();
  });

  importModal.addEventListener('click', (e) => {
    if (e.target === importModal) closeImportModal();
  });

  ccsChooserModal.addEventListener('click', (e) => {
    if (e.target === ccsChooserModal) resolveCCSImportChooser(null);
  });
}

function openCCSImportChooser(message, title = '选择导入目标') {
  return new Promise((resolve) => {
    if (pendingCCSImportChoiceResolver) {
      pendingCCSImportChoiceResolver(null);
    }
    pendingCCSImportChoiceResolver = resolve;
    ccsChooserTitle.textContent = title;
    ccsChooserText.textContent = message || '请选择导入到 CC-Switch 的目标应用。';
    ccsChooserModal.style.display = '';
    document.body.classList.add('modal-open');
  });
}

function closeCCSImportChooser() {
  ccsChooserModal.style.display = 'none';
  document.body.classList.remove('modal-open');
}

function resolveCCSImportChooser(target) {
  const resolver = pendingCCSImportChoiceResolver;
  pendingCCSImportChoiceResolver = null;
  closeCCSImportChooser();
  if (resolver) {
    resolver(target ? normalizeCCSImportTarget(target) : null);
  }
}

function bindGlobalEvents() {
  document.addEventListener('click', (e) => {
    const target = e.target;
    if (!(target instanceof Element)) return;

    if (!target.closest('.settings-wrapper')) {
      closeSettingsMenu();
    }

    if (!target.closest('.tags-input-wrapper')) {
      hideTagsAutocomplete();
    }

    // Close backend dropdown when clicking outside
    if (!target.closest('.backend-dropdown') && !target.closest('.btn-backend') && !target.closest('#btnOpenBackend')) {
      const dropdown = document.querySelector('.backend-dropdown');
      if (dropdown) dropdown.remove();
    }
  });

  window.addEventListener('pagehide', () => {
    stopClipboardAutoDetect();
    flushQueryResultsNow();
  });
  window.addEventListener('focus', () => {
    detectClipboardApiKey();
  });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) return;
    detectClipboardApiKey();
  });
}

function init() {
  btnAddSite.addEventListener('click', openAddModal);
  btnQueryAll.addEventListener('click', queryAllSites);
  btnDetect.addEventListener('click', detectKeysFromPage);

  btnCloseModal.addEventListener('click', closeModal);
  btnCancelModal.addEventListener('click', closeModal);
  siteForm.addEventListener('submit', handleSiteFormSubmit);
  btnToggleKey.addEventListener('click', toggleKeyVisibility);

  btnCloseDetail.addEventListener('click', closeDetailModal);

  btnSettings.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleSettingsMenu();
  });

  btnBatchImport.addEventListener('click', () => {
    closeSettingsMenu();
    openBatchModal();
  });

  btnExport.addEventListener('click', () => {
    closeSettingsMenu();
    exportSites();
  });

  btnImport.addEventListener('click', () => {
    closeSettingsMenu();
    openImportModal();
  });

  btnExportCCS.addEventListener('click', () => {
    closeSettingsMenu();
    exportAllToCCS();
  });

  btnCloseCCSChooser.addEventListener('click', () => resolveCCSImportChooser(null));
  btnCancelCCSChooser.addEventListener('click', () => resolveCCSImportChooser(null));
  btnChooseCCSCodex.addEventListener('click', () => resolveCCSImportChooser('codex'));
  btnChooseCCSClaude.addEventListener('click', () => resolveCCSImportChooser('claude'));

  btnToggleTheme.addEventListener('click', () => {
    toggleTheme();
  });

  btnCloseBatch.addEventListener('click', closeBatchModal);
  btnCancelBatch.addEventListener('click', closeBatchModal);
  btnDoBatch.addEventListener('click', doBatchImport);
  batchInput.addEventListener('input', renderBatchPreview);
  batchTagsInput.addEventListener('input', renderBatchPreview);

  btnCloseImport.addEventListener('click', closeImportModal);
  btnCancelImport.addEventListener('click', closeImportModal);
  btnDoImport.addEventListener('click', importSitesFromFile);
  importFileInput.addEventListener('change', loadImportPreviewFromFile);

  quickImportEl.addEventListener('paste', () => {
    setTimeout(() => handleQuickImport(), 50);
  });

  let _searchDebounceTimer = null;
  searchInput.addEventListener('input', () => {
    clearTimeout(_searchDebounceTimer);
    _searchDebounceTimer = setTimeout(() => renderSiteList(), 120);
  });
  tagFilterBar.addEventListener('click', (e) => {
    const target = e.target;
    if (!(target instanceof Element)) return;
    const btn = target.closest('.tag-pill');
    if (!btn || !btn.dataset.tag) return;
    toggleTagFilter(btn.dataset.tag);
  });

  siteListEl.addEventListener('click', handleSiteListClick);
  siteListEl.addEventListener('mousedown', (e) => {
    lastMouseDownTarget = e.target instanceof Element ? e.target : null;
  });
  siteListEl.addEventListener('dragstart', onSiteListDragStart);
  siteListEl.addEventListener('dragover', onSiteListDragOver);
  siteListEl.addEventListener('drop', onSiteListDrop);
  siteListEl.addEventListener('dragend', onSiteListDragEnd);

  btnOpenUrl.addEventListener('click', () => {
    const url = siteBaseUrlInput.value.trim();
    if (url) {
      chrome.tabs.create({ url });
    } else {
      showToast('请先输入 Base URL', 'error');
    }
  });

  btnOpenBackend.addEventListener('click', () => {
    const url = siteBaseUrlInput.value.trim();
    if (!url) {
      showToast('请先输入 Base URL', 'error');
      return;
    }
    openBackendPanel(url);
  });

  btnDetectFormat.addEventListener('click', () => {
    const url = siteBaseUrlInput.value.trim();
    const key = siteApiKeyInput.value.trim();
    if (!url) {
      showToast('请先输入 Base URL', 'error');
      return;
    }
    detectSiteFormatAndHealth(url, key);
  });

  enableDraftAutoSave();
  bindTagInputEvents();
  bindModalEvents();
  bindGlobalEvents();

  Promise.all([
    loadTheme(),
    new Promise((resolve) => {
      chrome.storage.local.get('queryResults', (data) => {
        queryResults = data.queryResults || {};
        resolve();
      });
    }),
  ]).then(async () => {
    await loadSites();
    sitesLoaded = true;
    renderSiteList();
    startClipboardAutoDetect(); window.addEventListener('beforeunload', stopClipboardAutoDetect);
  });
}

document.addEventListener('DOMContentLoaded', init);
