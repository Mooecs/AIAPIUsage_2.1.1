/**
 * AI API Toolkit — Rendering Functions
 * All UI rendering, detail modals, model display, tags display.
 * Depends on: constants.js, utils.js (helpers), popup.js (state + DOM refs)
 */

// ============================================
// Shared Rendering Helpers
// ============================================

function usageValueClass(available, pct) {
  if (available <= 0) return 'danger';
  if (pct > 70) return 'warning';
  return 'success';
}

function calcUsagePct(used, total) {
  if (total <= 0) return 0;
  // Return raw percentage for precision, formatting done at render time
  return (used / total) * 100;
}

function renderUsageSummary(stats) {
  return '<div class="usage-summary">' + stats.map((s) => `
    <div class="usage-stat">
      <div class="usage-stat-label">${s.label}</div>
      <div class="usage-stat-value ${s.cls || ''}">${s.value}</div>
      ${s.sub ? `<div class="usage-stat-label" style="margin-top:1px;">${s.sub}</div>` : ''}
    </div>
  `).join('') + '</div>';
}

function renderProgressBar(label, used, total) {
  const pct = calcUsagePct(used, total);
  const barClass = pct > 80 ? 'danger' : pct > 50 ? 'warning' : '';
  return `
    <div class="progress-bar-container">
      <div class="progress-bar-header">
        <span>${label}</span>
        <span>${Math.min(pct, 100).toFixed(1)}%</span>
      </div>
      <div class="progress-bar">
        <div class="progress-bar-fill ${barClass}" style="width: ${Math.min(pct, 100)}%"></div>
      </div>
    </div>
  `;
}

// ============================================
// Detected Banner
// ============================================

function renderDetectedBanner(keys) {
  if (!keys || keys.length === 0) {
    detectedBanner.style.display = 'none';
    detectedBanner.innerHTML = '';
    return;
  }

  detectedBanner.innerHTML = `
    <div class="detected-header">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="11" cy="11" r="8"/>
        <line x1="21" y1="21" x2="16.65" y2="16.65"/>
      </svg>
      <span>检测到 ${keys.length} 个 API Key</span>
      <button class="detected-close" title="关闭">&times;</button>
    </div>
    ${keys.map((item, i) => `
      <div class="detected-item" data-detect-index="${i}">
        <code class="detected-key">${escapeHtml(item.maskedKey)}</code>
        <span class="detected-source">${escapeHtml(item.source)}</span>
        <input class="detected-url-input" data-detect-url="${i}" value="${escapeHtml(item.inferredBaseUrl)}" placeholder="Base URL" title="可修改 Base URL">
        <div class="detected-actions">
          <select class="detected-format-select" data-detect-format="${i}" title="API 格式">
            <option value="">自动</option>
            <option value="new-api">new-api</option>
            <option value="one-api">OneAPI</option>
            <option value="sub2api">sub2api</option>
            <option value="cch">CCH</option>
            <option value="openai">OpenAI</option>
          </select>
          <button class="btn btn-xs btn-primary detected-query" data-detect-index="${i}" title="直接查额">查额</button>
          <button class="btn btn-xs btn-accent detected-add" data-detect-index="${i}" title="添加到站点列表">添加</button>
        </div>
      </div>
    `).join('')}
  `;

  detectedBanner.style.display = '';

  // Event delegation for banner
  detectedBanner.onclick = (e) => {
    const target = e.target;
    if (!(target instanceof Element)) return;
    if (target.classList.contains('detected-close')) {
      detectedBanner.style.display = 'none';
      return;
    }

    const btn = target.closest('[data-detect-index]');
    if (!btn) return;
    const idx = Number(btn.dataset.detectIndex);
    const urlInput = detectedBanner.querySelector(`input[data-detect-url="${idx}"]`);
    const editedUrl = urlInput ? urlInput.value.trim() : '';
    const formatSelect = detectedBanner.querySelector(`select[data-detect-format="${idx}"]`);
    const selectedFormat = formatSelect ? formatSelect.value : '';

    if (btn.classList.contains('detected-query')) {
      queryDetectedKey(idx, editedUrl, selectedFormat);
    } else if (btn.classList.contains('detected-add')) {
      addDetectedKey(idx, editedUrl);
    }
  };
}

function getAllTags() {
  const tagSet = new Set();
  for (const site of sites) {
    for (const tag of site.tags || []) {
      tagSet.add(tag);
    }
  }
  return Array.from(tagSet).sort((a, b) => a.localeCompare(b, 'zh-CN'));
}

function getTagCounts() {
  const counts = new Map();
  for (const site of sites) {
    for (const tag of site.tags || []) {
      counts.set(tag, (counts.get(tag) || 0) + 1);
    }
  }
  return counts;
}

function isFilteringActive() {
  const query = (searchInput.value || '').trim();
  return Boolean(query) || activeTagFilters.size > 0;
}

function canDragSort() {
  return sites.length > 1 && !isFilteringActive();
}

function getFilteredSites() {
  const query = (searchInput.value || '').trim().toLowerCase();
  const activeTags = Array.from(activeTagFilters).map((tag) => tag.toLowerCase());

  return sites.filter((site) => {
    const matchedQuery = !query ||
      (site.name || '').toLowerCase().includes(query) ||
      (site.baseUrl || '').toLowerCase().includes(query) ||
      (site.notes || '').toLowerCase().includes(query) ||
      (site.tags || []).some((tag) => tag.toLowerCase().includes(query));

    const matchedTags = activeTags.length === 0 ||
      (site.tags || []).some((tag) => activeTags.includes(tag.toLowerCase()));

    return matchedQuery && matchedTags;
  });
}

function renderTagFilterBar() {
  const allTags = getAllTags();
  if (allTags.length === 0) {
    tagFilterBar.style.display = 'none';
    activeTagFilters.clear();
    return;
  }

  const validTagSet = new Set(allTags.map((tag) => tag.toLowerCase()));
  for (const tag of Array.from(activeTagFilters)) {
    if (!validTagSet.has(tag.toLowerCase())) {
      activeTagFilters.delete(tag);
    }
  }

  const counts = getTagCounts();
  tagFilterBar.innerHTML = allTags.map((tag) => {
    const active = activeTagFilters.has(tag) ? 'active' : '';
    return `
      <button class="tag-pill ${active}" data-tag="${escapeHtml(tag)}" title="点击筛选">
        ${escapeHtml(tag)}
        <span class="tag-count">${counts.get(tag) || 0}</span>
      </button>
    `;
  }).join('');

  tagFilterBar.style.display = '';
}

function toggleTagFilter(tag) {
  if (activeTagFilters.has(tag)) {
    activeTagFilters.delete(tag);
  } else {
    activeTagFilters.add(tag);
  }
  renderSiteList();
}

function renderSiteTags(tags) {
  if (!tags || tags.length === 0) return '';
  return `
    <div class="site-tags-display">
      ${tags.map((tag) => `<span class="site-tag-badge">${escapeHtml(tag)}</span>`).join('')}
    </div>
  `;
}

let _renderSiteListRAF = 0;
let _lastSiteListHTML = '';

function renderSiteList() {
  // Batch multiple calls within the same frame
  cancelAnimationFrame(_renderSiteListRAF);
  _renderSiteListRAF = requestAnimationFrame(_renderSiteListImmediate);
}

function _renderSiteListImmediate() {
  if (sites.length >= 3) {
    searchBar.style.display = '';
  } else {
    searchBar.style.display = 'none';
    searchInput.value = '';
  }

  renderTagFilterBar();

  if (sites.length === 0) {
    siteListEl.style.display = 'none';
    emptyStateEl.style.display = '';
    _lastSiteListHTML = '';
    persistQueryResults();
    return;
  }

  siteListEl.style.display = '';
  emptyStateEl.style.display = 'none';

  const filtered = getFilteredSites();
  const draggable = canDragSort();

  if (filtered.length === 0) {
    const emptyHTML = '<div class="empty-state" style="min-height:80px;"><p class="text-muted">无匹配站点</p></div>';
    if (_lastSiteListHTML !== emptyHTML) {
      siteListEl.innerHTML = emptyHTML;
      _lastSiteListHTML = emptyHTML;
    }
    persistQueryResults();
    return;
  }

  const html = filtered.map((site) => {
    const result = queryResults[site.id];
    return `
      <div class="site-card" data-id="${escapeHtml(site.id)}" draggable="${draggable ? 'true' : 'false'}">
        <div class="site-card-header">
          <div class="drag-handle" title="${draggable ? '拖拽排序' : '有筛选条件时不可拖拽'}">⋮⋮</div>
          <div class="site-info">
            <div class="site-name">
              <span class="site-status-dot unknown" title="点击检测存活状态"></span>
              ${escapeHtml(site.name)}
              ${site.detectedFormat ? `<span class="site-format-badge">${escapeHtml(site.detectedFormat)}</span>` : ''}
              ${site.notes ? `<span class="text-accent" style="font-size:10px;margin-left:4px;" title="${escapeHtml(site.notes)}">ⓘ</span>` : ''}
            </div>
            <div class="site-url">${escapeHtml(site.baseUrl)}</div>
            ${renderSiteTags(site.tags)}
          </div>
        </div>
        <div class="site-toolbar">
          <div class="toolbar-group">
            <button class="btn btn-xs btn-primary btn-query" data-id="${escapeHtml(site.id)}" title="查询额度">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"/><polyline points="23 20 23 14 17 14"/><path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15"/></svg>
              查额
            </button>
            <button class="btn btn-xs btn-accent btn-models" data-id="${escapeHtml(site.id)}" title="查询可用模型">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
              模型
            </button>
            <button class="btn btn-xs btn-chat-test" data-id="${escapeHtml(site.id)}" title="发送 Hi 进行聊天测试">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
              测试
            </button>
          </div>
          <div class="toolbar-group">
            <button class="btn btn-xs btn-ghost btn-copy-url" data-id="${escapeHtml(site.id)}" title="复制 Base URL">URL</button>
            <button class="btn btn-xs btn-ghost btn-copy-key" data-id="${escapeHtml(site.id)}" title="复制 API Key">Key</button>
            <button class="btn btn-xs btn-ghost btn-ccs" data-id="${escapeHtml(site.id)}" title="选择导入到 CC-Switch 的目标">CCS</button>
            <button class="btn btn-xs btn-ghost btn-open-site" data-id="${escapeHtml(site.id)}" title="在浏览器中打开">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
            </button>
            <button class="btn btn-xs btn-ghost btn-backend" data-id="${escapeHtml(site.id)}" title="打开后台管理面板">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
            </button>
            <button class="btn btn-xs btn-ghost btn-health-check" data-id="${escapeHtml(site.id)}" title="检测站点存活">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
            </button>
          </div>
          <div class="toolbar-spacer"></div>
          <div class="toolbar-group">
            <button class="btn-icon btn-edit" data-id="${escapeHtml(site.id)}" title="编辑">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </button>
            <button class="btn-icon btn-delete" data-id="${escapeHtml(site.id)}" title="删除">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
            </button>
          </div>
        </div>
        ${result ? renderSiteResult(site, result) : ''}
      </div>
    `;
  }).join('');

  // Skip DOM update if content hasn't changed
  if (html !== _lastSiteListHTML) {
    siteListEl.innerHTML = html;
    _lastSiteListHTML = html;
  }

  persistQueryResults();
}

function getFormatDebugLabel(format) {
  const labels = {
    'new-api': 'new-api',
    'one-api': 'OneAPI',
    sub2api: 'sub2api',
    cch: 'CCH',
    openai: 'OpenAI 兼容',
  };
  return labels[format] || format || '未知格式';
}

function renderQueryDebugDetails(debugSteps) {
  if (!Array.isArray(debugSteps) || debugSteps.length === 0) return '';

  const rows = debugSteps.map((step) => {
    const statusLabel = step.status === 'success'
      ? '成功'
      : step.status === 'info'
        ? '信息'
        : '失败';
    const endpoint = step.endpoint ? escapeHtml(step.endpoint) : '—';
    const method = escapeHtml(step.method || 'GET');
    const format = escapeHtml(getFormatDebugLabel(step.format));
    const message = escapeHtml(step.message || '无附加信息');
    const statusClass = step.status === 'success'
      ? 'success'
      : step.status === 'info'
        ? ''
        : 'danger';

    return `
      <tr>
        <td>${format}</td>
        <td>${method}</td>
        <td class="${statusClass}">${statusLabel}</td>
        <td style="font-size:10px;word-break:break-all;">${endpoint}</td>
        <td style="font-size:10px;">${message}</td>
      </tr>
    `;
  }).join('');

  return `
    <details style="margin-top:10px;">
      <summary style="cursor:pointer;color:var(--text-secondary);font-size:11px;">调试信息：查看格式探测和失败原因</summary>
      <div class="table-container" style="margin-top:8px;">
        <table class="usage-table">
          <thead>
            <tr>
              <th>格式</th>
              <th>方法</th>
              <th>状态</th>
              <th>端点</th>
              <th>说明</th>
            </tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </details>
  `;
}

function renderQueryFailureContent(result, fallbackMessage) {
  const errorMessage = escapeHtml((result && result.error) || fallbackMessage || '查询失败');
  const debugDetails = renderQueryDebugDetails(result && result.debug);

  return `
    <div class="error-message">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"/>
        <line x1="15" y1="9" x2="9" y2="15"/>
        <line x1="9" y1="9" x2="15" y2="15"/>
      </svg>
      <span>${errorMessage}</span>
    </div>
    ${debugDetails}
  `;
}

function renderSiteResult(site, result) {
  if (result.loading) {
    return `
      <div class="site-result">
        <div class="loading-spinner">
          <div class="spinner"></div>
          正在查询...
        </div>
      </div>
    `;
  }
  if (!result.success) {
    return `
      <div class="site-result">
        ${renderQueryFailureContent(result, '查询失败')}
      </div>
    `;
  }

  const data = result.data;
  const format = result.format;

  if (!data) {
    return `
      <div class="site-result">
        <div class="error-message"><span>响应中无数据</span></div>
      </div>
    `;
  }

  if (format === 'sub2api') {
    return renderSub2apiCard(data);
  }
  if (format === 'cch') {
    return renderCCHCard(data);
  }
  if (format === 'one-api') {
    return renderOneApiCard(data);
  }
  if (format === 'openai') {
    return renderOpenAICard(data);
  }
  return renderNewApiCard(data);
}

function renderNewApiCard(rawData) {
  if (!rawData) return '<div class="site-result"><div class="error-message"><span>无数据</span></div></div>';
  const data = rawData.data || rawData;
  let html = '<div class="site-result">';

  if (data.unlimited_quota) {
    html += '<div style="margin-bottom:8px;"><span class="badge badge-green">无限额度</span></div>';
  } else if (data.total_granted > 0 || data.total_available != null) {
    const total = Number(data.total_granted || 0);
    const used = Number(data.total_used || 0);
    const available = Number(data.total_available ?? (total - used));
    const pct = calcUsagePct(used, total);
    const valClass = usageValueClass(available, pct);

    html += renderUsageSummary([
      { label: '可用', value: toUSD(available), sub: fmtNum(available), cls: valClass },
      { label: '已用', value: toUSD(used), sub: fmtNum(used) },
      { label: '总额', value: toUSD(total), sub: fmtNum(total) },
    ]);
    html += renderProgressBar('使用率', used, total);
  }

  if (data.expires_at > 0) {
    const expiryStr = formatExpiry(data.expires_at);
    if (expiryStr) {
      html += `
        <div class="info-row">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10"/>
            <polyline points="12 6 12 12 16 14"/>
          </svg>
          <span class="info-row-label">过期时间</span>
          <span>${expiryStr}</span>
        </div>
      `;
    }
  }

  if (data.model_limits && typeof data.model_limits === 'object') {
    const models = Object.keys(data.model_limits).filter((k) => data.model_limits[k]);
    if (models.length > 0) {
      const displayModels = models.slice(0, 8);
      const moreCount = models.length - displayModels.length;
      html += `
        <div class="info-row" style="align-items:flex-start;">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-top:3px;">
            <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
            <line x1="8" y1="21" x2="16" y2="21"/>
            <line x1="12" y1="17" x2="12" y2="21"/>
          </svg>
          <div>
            <span class="info-row-label">模型</span>
            <span class="text-muted">(${models.length})</span>
            ${data.model_limits_enabled ? '<span class="badge badge-green" style="margin-left:4px;">限制启用</span>' : ''}
            <div class="model-tags">
              ${displayModels.map((m) => `<span class="model-tag">${escapeHtml(m)}</span>`).join('')}
              ${moreCount > 0 ? `<span class="model-tag text-accent">+${moreCount}</span>` : ''}
            </div>
          </div>
        </div>
      `;
    }
  }

  html += renderViewDetailBtn();
  html += '</div>';
  return html;
}

function renderSub2apiCard(data) {
  let html = '<div class="site-result">';

  html += '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:8px;">';
  if (data.planName) html += `<span style="font-weight:600;font-size:12px;">📊 ${escapeHtml(data.planName)}</span>`;
  const modeMap = { quota_limited: '额度限制', unrestricted: '无限制' };
  const modeLabel = modeMap[data.mode] || data.mode || '';
  if (modeLabel) {
    const modeColor = data.mode === 'unrestricted' ? 'badge-green' : 'badge-orange';
    html += `<span class="badge ${modeColor}">${escapeHtml(modeLabel)}</span>`;
  }
  if (data.status) html += `<span class="badge badge-green">${escapeHtml(data.status)}</span>`;
  if (data.isValid === false) html += '<span class="badge badge-red">无效</span>';
  html += '</div>';

  if (data.quota && data.quota.limit > 0) {
    const used = Number(data.quota.used || 0);
    const limit = Number(data.quota.limit || 0);
    const remain = Number(data.quota.remaining ?? (limit - used));
    const pct = calcUsagePct(used, limit);
    const valClass = usageValueClass(remain, pct);

    html += renderUsageSummary([
      { label: '剩余', value: toUSDDirect(remain), cls: valClass },
      { label: '已用', value: toUSDDirect(used) },
      { label: '总额', value: toUSDDirect(limit) },
    ]);
    html += renderProgressBar('使用率', used, limit);
  } else if (data.mode === 'unrestricted') {
    html += '<span class="badge badge-green">无限额度</span>';
    if (data.balance !== undefined) {
      html += ` <span class="text-muted" style="font-size:12px;">余额: ${toUSDDirect(data.balance)}</span>`;
    }
    html += '<br>';
  }

  if (data.usage && data.usage.today) {
    const t = data.usage.today;
    html += `
      <div class="usage-stats-grid" style="margin-top:8px;">
        <div class="usage-stat">
          <div class="usage-stat-label">今日请求</div>
          <div class="usage-stat-value">${fmtNum(t.requests)}</div>
        </div>
        <div class="usage-stat">
          <div class="usage-stat-label">今日花费</div>
          <div class="usage-stat-value">${toUSDDirect(t.cost)}</div>
        </div>
        <div class="usage-stat">
          <div class="usage-stat-label">今日Token</div>
          <div class="usage-stat-value">${fmtNum(t.total_tokens)}</div>
        </div>
      </div>
    `;
  }

  html += renderViewDetailBtn();
  html += '</div>';
  return html;
}

function renderCCHQuotaBar(label, current, limit) {
  if (limit === null || limit === undefined || limit <= 0) return '';
  const pct = (current / limit) * 100;
  const barClass = pct > 80 ? 'danger' : pct > 50 ? 'warning' : '';
  const remain = Math.max(0, limit - current);
  const valClass = remain <= 0 ? 'danger' : pct > 70 ? 'warning' : 'success';
  return `
    <div style="margin-bottom:6px;">
      <div class="progress-bar-header">
        <span>${escapeHtml(label)} <span class="${valClass}" style="font-weight:600;">${current.toFixed(2)}</span> / ${limit.toFixed(2)}</span>
        <span>${Math.min(pct, 100).toFixed(1)}%</span>
      </div>
      <div class="progress-bar">
        <div class="progress-bar-fill ${barClass}" style="width: ${Math.min(pct, 100)}%"></div>
      </div>
    </div>
  `;
}

function cchFmtQuota(current, limit) {
  const cur = '$' + Number(current || 0).toFixed(2);
  if (limit === null || limit === undefined) return `${cur}/∞`;
  return `${cur}/$${Number(limit).toFixed(2)}`;
}

function cchQuotaClass(current, limit) {
  if (limit === null || limit === undefined || limit <= 0) return '';
  const pct = Number(current || 0) / limit;
  if (pct > 0.8) return 'danger';
  if (pct > 0.5) return 'warning';
  return 'success';
}

function renderCCHCard(data) {
  let html = '<div class="site-result">';

  // Key info badge
  html += '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:8px;">';
  html += '<span class="badge badge-green">CCH</span>';
  if (data.keyName) html += `<span style="font-weight:600;font-size:12px;">${escapeHtml(data.keyName)}</span>`;
  if (data.userName) html += `<span class="text-muted" style="font-size:11px;">${escapeHtml(data.userName)}</span>`;
  if (data.keyIsEnabled === false) html += '<span class="badge badge-red">已禁用</span>';
  html += '</div>';

  // Stats grid: ordered by importance
  // 5h → daily → weekly → monthly → total → requests/concurrent
  const stats = [
    { label: '5h 限额', value: cchFmtQuota(data.keyCurrent5hUsd, data.keyLimit5hUsd), cls: cchQuotaClass(data.keyCurrent5hUsd, data.keyLimit5hUsd) },
    { label: '今日花费', value: cchFmtQuota(data.keyCurrentDailyUsd, data.keyLimitDailyUsd), cls: cchQuotaClass(data.keyCurrentDailyUsd, data.keyLimitDailyUsd) },
    { label: '本周花费', value: cchFmtQuota(data.keyCurrentWeeklyUsd, data.keyLimitWeeklyUsd), cls: cchQuotaClass(data.keyCurrentWeeklyUsd, data.keyLimitWeeklyUsd) },
    { label: '本月花费', value: cchFmtQuota(data.keyCurrentMonthlyUsd, data.keyLimitMonthlyUsd), cls: cchQuotaClass(data.keyCurrentMonthlyUsd, data.keyLimitMonthlyUsd) },
    { label: '累计花费', value: cchFmtQuota(data.keyCurrentTotalUsd, data.keyLimitTotalUsd), cls: cchQuotaClass(data.keyCurrentTotalUsd, data.keyLimitTotalUsd) },
  ];

  // Requests / Concurrent (merged)
  const calls = data.todayStats ? fmtNum(data.todayStats.calls) : '—';
  const concurrent = `${fmtNum(data.keyCurrentConcurrentSessions ?? 0)}/${data.keyLimitConcurrentSessions ?? '∞'}`;
  stats.push({ label: '请求/并发', value: `${calls} · ${concurrent}`, cls: '' });

  html += '<div class="usage-stats-grid">';
  stats.forEach((s) => {
    html += `
      <div class="usage-stat">
        <div class="usage-stat-label">${s.label}</div>
        <div class="usage-stat-value ${s.cls}">${s.value}</div>
      </div>
    `;
  });
  html += '</div>';

  html += renderViewDetailBtn();
  html += '</div>';
  return html;
}

function renderCCHDetail(data) {
  let html = '';

  // Header
  html += '<div class="detail-section">';
  html += '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:12px;">';
  html += '<span class="badge badge-green">Claude Code Hub</span>';
  if (data.keyName) html += `<span style="font-weight:700;font-size:14px;">${escapeHtml(data.keyName)}</span>`;
  if (data.userName) html += `<span class="text-muted" style="font-size:12px;">${escapeHtml(data.userName)}</span>`;
  if (data.keyIsEnabled === false) html += '<span class="badge badge-red">Key 已禁用</span>';
  if (data.userIsEnabled === false) html += '<span class="badge badge-red">用户已禁用</span>';
  html += '</div>';

  // Expiry
  if (data.expiresAt) {
    const expiryStr = formatExpiry(data.expiresAt);
    if (expiryStr) {
      html += `<div class="info-row"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg><span>过期时间: ${expiryStr}</span></div>`;
    }
  }

  // Provider group
  if (data.keyProviderGroup) {
    html += `<div class="info-row" style="margin-top:4px;"><span class="info-row-label">供应商分组</span><span class="badge badge-green">${escapeHtml(data.keyProviderGroup)}</span></div>`;
  }
  html += '</div>';

  // Usage summary (same format as card view)
  html += '<div class="detail-section">';
  html += '<div class="detail-section-title">费用概览</div>';
  html += '<div class="usage-stats-grid">';
  const overviewStats = [
    { label: '5h 限额', value: cchFmtQuota(data.keyCurrent5hUsd, data.keyLimit5hUsd), cls: cchQuotaClass(data.keyCurrent5hUsd, data.keyLimit5hUsd) },
    { label: '今日花费', value: cchFmtQuota(data.keyCurrentDailyUsd, data.keyLimitDailyUsd), cls: cchQuotaClass(data.keyCurrentDailyUsd, data.keyLimitDailyUsd) },
    { label: '本周花费', value: cchFmtQuota(data.keyCurrentWeeklyUsd, data.keyLimitWeeklyUsd), cls: cchQuotaClass(data.keyCurrentWeeklyUsd, data.keyLimitWeeklyUsd) },
    { label: '本月花费', value: cchFmtQuota(data.keyCurrentMonthlyUsd, data.keyLimitMonthlyUsd), cls: cchQuotaClass(data.keyCurrentMonthlyUsd, data.keyLimitMonthlyUsd) },
    { label: '累计花费', value: cchFmtQuota(data.keyCurrentTotalUsd, data.keyLimitTotalUsd), cls: cchQuotaClass(data.keyCurrentTotalUsd, data.keyLimitTotalUsd) },
  ];
  const detailCalls = data.todayStats ? fmtNum(data.todayStats.calls) : '—';
  const detailConcurrent = `${fmtNum(data.keyCurrentConcurrentSessions ?? 0)}/${data.keyLimitConcurrentSessions ?? '∞'}`;
  overviewStats.push({ label: '请求/并发', value: `${detailCalls} · ${detailConcurrent}`, cls: '' });
  overviewStats.forEach((s) => {
    html += `<div class="usage-stat"><div class="usage-stat-label">${s.label}</div><div class="usage-stat-value ${s.cls}">${s.value}</div></div>`;
  });
  html += '</div>';
  html += '</div>';

  // Key quota section
  html += '<div class="detail-section"><div class="detail-section-title">Key 限额</div>';
  const keyQuotas = [
    { label: '5小时', current: data.keyCurrent5hUsd, limit: data.keyLimit5hUsd },
    { label: '每日', current: data.keyCurrentDailyUsd, limit: data.keyLimitDailyUsd },
    { label: '每周', current: data.keyCurrentWeeklyUsd, limit: data.keyLimitWeeklyUsd },
    { label: '每月', current: data.keyCurrentMonthlyUsd, limit: data.keyLimitMonthlyUsd },
    { label: '总额', current: data.keyCurrentTotalUsd, limit: data.keyLimitTotalUsd },
  ];
  html += '<div class="table-container"><table class="usage-table">';
  html += '<thead><tr><th>周期</th><th class="num">已用</th><th class="num">限额</th><th class="num">使用率</th></tr></thead><tbody>';
  keyQuotas.forEach((q) => {
    const cur = Number(q.current || 0);
    const lim = q.limit;
    const limStr = lim !== null && lim !== undefined ? `$${Number(lim).toFixed(2)}` : '无限制';
    const pct = lim ? (cur / lim * 100).toFixed(1) + '%' : '—';
    const cls = lim && cur / lim > 0.8 ? 'danger' : lim && cur / lim > 0.5 ? 'warning' : '';
    html += `<tr><td>${q.label}</td><td class="num">$${cur.toFixed(2)}</td><td class="num">${limStr}</td><td class="num ${cls}">${pct}</td></tr>`;
  });
  html += '</tbody></table></div>';

  // Concurrent sessions
  html += `<div class="info-row" style="margin-top:8px;"><span class="info-row-label">并发 Session</span><span>${fmtNum(data.keyCurrentConcurrentSessions ?? 0)}${data.keyLimitConcurrentSessions != null ? ' / ' + data.keyLimitConcurrentSessions : ' (无限制)'}</span></div>`;
  html += '</div>';

  // User quota section (only if different from key)
  const hasUserLimits = data.userLimit5hUsd !== null || data.userLimitDailyUsd !== null ||
    data.userLimitWeeklyUsd !== null || data.userLimitMonthlyUsd !== null || data.userLimitTotalUsd !== null;
  if (hasUserLimits) {
    html += '<div class="detail-section"><div class="detail-section-title">用户限额</div>';
    const userQuotas = [
      { label: '5小时', current: data.userCurrent5hUsd, limit: data.userLimit5hUsd },
      { label: '每日', current: data.userCurrentDailyUsd, limit: data.userLimitDailyUsd },
      { label: '每周', current: data.userCurrentWeeklyUsd, limit: data.userLimitWeeklyUsd },
      { label: '每月', current: data.userCurrentMonthlyUsd, limit: data.userLimitMonthlyUsd },
      { label: '总额', current: data.userCurrentTotalUsd, limit: data.userLimitTotalUsd },
    ];
    html += '<div class="table-container"><table class="usage-table">';
    html += '<thead><tr><th>周期</th><th class="num">已用</th><th class="num">限额</th><th class="num">使用率</th></tr></thead><tbody>';
    userQuotas.forEach((q) => {
      const cur = Number(q.current || 0);
      const lim = q.limit;
      const limStr = lim !== null && lim !== undefined ? `$${Number(lim).toFixed(2)}` : '无限制';
      const pct = lim ? (cur / lim * 100).toFixed(1) + '%' : '—';
      html += `<tr><td>${q.label}</td><td class="num">$${cur.toFixed(2)}</td><td class="num">${limStr}</td><td class="num">${pct}</td></tr>`;
    });
    html += '</tbody></table></div></div>';
  }

  // Today stats section
  if (data.todayStats) {
    const ts = data.todayStats;
    html += '<div class="detail-section"><div class="detail-section-title">今日统计</div>';
    html += '<div class="usage-stats-grid">';
    html += `<div class="usage-stat"><div class="usage-stat-label">请求数</div><div class="usage-stat-value">${fmtNum(ts.calls)}</div></div>`;
    html += `<div class="usage-stat"><div class="usage-stat-label">花费</div><div class="usage-stat-value">$${Number(ts.costUsd || 0).toFixed(2)}</div></div>`;
    html += `<div class="usage-stat"><div class="usage-stat-label">输入 Token</div><div class="usage-stat-value">${fmtNum(ts.inputTokens)}</div></div>`;
    html += `<div class="usage-stat"><div class="usage-stat-label">输出 Token</div><div class="usage-stat-value">${fmtNum(ts.outputTokens)}</div></div>`;
    html += '</div>';

    // Model breakdown table
    if (ts.modelBreakdown && ts.modelBreakdown.length > 0) {
      const models = ts.modelBreakdown.slice().sort((a, b) => (b.costUsd || 0) - (a.costUsd || 0));
      html += `<div class="detail-section-title" style="margin-top:12px;">模型用量 (${models.length})</div>`;
      html += '<div class="table-container"><table class="usage-table">';
      html += '<thead><tr><th>模型</th><th class="num">请求</th><th class="num">输入</th><th class="num">输出</th><th class="num">花费</th></tr></thead><tbody>';
      models.forEach((m) => {
        html += `<tr>
          <td><span class="model-tag">${escapeHtml(m.model || '未知')}</span></td>
          <td class="num">${fmtNum(m.calls)}</td>
          <td class="num">${fmtNum(m.inputTokens)}</td>
          <td class="num">${fmtNum(m.outputTokens)}</td>
          <td class="num">$${Number(m.costUsd || 0).toFixed(4)}</td>
        </tr>`;
      });
      html += '</tbody></table></div>';
    }
    html += '</div>';
  }

  return html;
}

function renderOneApiCard(data) {
  let html = '<div class="site-result">';

  html += '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:8px;">';
  html += '<span class="badge badge-blue">OneAPI</span>';
  if (data.username) html += `<span style="font-weight:600;font-size:12px;">${escapeHtml(data.display_name || data.username)}</span>`;
  const roleMap = { 1: '普通用户', 10: '管理员', 100: '超级管理员' };
  if (data.role !== undefined) {
    const roleName = roleMap[data.role] || '角色 ' + data.role;
    html += `<span class="badge badge-green">${escapeHtml(roleName)}</span>`;
  }
  if (data.status === 2) html += '<span class="badge badge-red">已禁用</span>';
  html += '</div>';

  const quota = Number(data.quota || 0);
  const usedQuota = Number(data.used_quota || 0);
  const totalQuota = quota + usedQuota;

  if (totalQuota > 0 || quota > 0) {
    const available = quota;
    const pct = calcUsagePct(usedQuota, totalQuota);
    const valClass = usageValueClass(available, pct);

    html += renderUsageSummary([
      { label: '可用', value: toUSD(available), sub: fmtNum(available), cls: valClass },
      { label: '已用', value: toUSD(usedQuota), sub: fmtNum(usedQuota) },
      { label: '总额', value: toUSD(totalQuota), sub: fmtNum(totalQuota) },
    ]);
    html += renderProgressBar('使用率', usedQuota, totalQuota);
  }

  if (data.request_count !== undefined) {
    html += `
      <div class="info-row">
        <span class="info-row-label">请求总数</span>
        <span>${fmtNum(data.request_count)}</span>
      </div>
    `;
  }

  html += renderViewDetailBtn();
  html += '</div>';
  return html;
}

function renderOpenAICard(data) {
  let html = '<div class="site-result">';
  html += '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:8px;">';
  html += '<span class="badge badge-green">OpenAI 兼容</span>';
  if (data && data._openaiUsageType === 'billing') {
    html += '<span class="badge badge-blue">Billing</span>';
  }
  html += '</div>';

  if (data && data._openaiUsageType === 'billing') {
    const total = Number(data.total_granted || data.hard_limit_usd || 0);
    const used = Number(data.total_used || 0);
    const available = Number(data.total_available ?? Math.max(total - used, 0));
    const pct = calcUsagePct(used, total);
    const valClass = usageValueClass(available, pct);

    html += renderUsageSummary([
      { label: '可用', value: toUSDDirect(available), cls: valClass },
      { label: '已用', value: toUSDDirect(used) },
      { label: '总额', value: toUSDDirect(total) },
    ]);
    html += renderProgressBar('使用率', used, total);

    if (data.access_until) {
      const expiryStr = formatExpiry(data.access_until);
      if (expiryStr) {
        html += `
          <div class="info-row">
            <span class="info-row-label">到期时间</span>
            <span>${expiryStr}</span>
          </div>
        `;
      }
    }

    if (data.plan) {
      html += `
        <div class="info-row">
          <span class="info-row-label">套餐</span>
          <span>${escapeHtml(data.plan)}</span>
        </div>
      `;
    }

    html += renderViewDetailBtn();
    html += '</div>';
    return html;
  }

  let models = [];
  if (Array.isArray(data)) {
    models = data;
  } else if (data && Array.isArray(data.data)) {
    models = data.data;
  }

  if (models.length > 0) {
    const displayModels = models.slice(0, 6).map((m) => m.id || m.name || '');
    const moreCount = models.length - displayModels.length;
    html += `
      <div class="info-row" style="align-items:flex-start;">
        <div>
          <span class="info-row-label">可用模型</span>
          <span class="text-muted">(${models.length})</span>
          <div class="model-tags">
            ${displayModels.map((m) => `<span class="model-tag">${escapeHtml(m)}</span>`).join('')}
            ${moreCount > 0 ? `<span class="model-tag text-accent">+${moreCount}</span>` : ''}
          </div>
        </div>
      </div>
    `;
  }

  html += renderViewDetailBtn();
  html += '</div>';
  return html;
}

function renderViewDetailBtn() {
  return `
    <button class="btn-view-detail">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
        <circle cx="12" cy="12" r="3"/>
      </svg>
      查看详情
    </button>
  `;
}

function renderNewApiDetail(rawData) {
  if (!rawData) return '<div class="error-message"><span>无数据</span></div>';
  const data = rawData.data || rawData;
  let html = '';

  html += '<div class="detail-section"><div class="detail-section-title">额度概览</div>';
  if (data.unlimited_quota) {
    html += '<span class="badge badge-green">无限额度</span>';
  } else {
    const total = Number(data.total_granted || 0);
    const used = Number(data.total_used || 0);
    const available = Number(data.total_available ?? (total - used));

    html += renderUsageSummary([
      { label: '可用', value: toUSD(available), sub: fmtNum(available), cls: 'success' },
      { label: '已用', value: toUSD(used), sub: fmtNum(used), cls: 'warning' },
      { label: '总额', value: toUSD(total), sub: fmtNum(total) },
    ]);
    html += renderProgressBar('使用率', used, total);
  }
  html += '</div>';

  if (data.expires_at > 0) {
    const expiryStr = formatExpiry(data.expires_at);
    if (expiryStr) {
      html += `<div class="detail-section"><div class="detail-section-title">过期时间</div>
        <div class="info-row"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
        <span>${expiryStr}</span></div></div>`;
    }
  }

  if (data.model_limits && typeof data.model_limits === 'object') {
    const models = Object.keys(data.model_limits).filter((k) => data.model_limits[k]);
    if (models.length > 0) {
      html += `<div class="detail-section"><div class="detail-section-title">可用模型 (${models.length})</div>`;
      if (data.model_limits_enabled) {
        html += '<div style="margin-bottom:6px;"><span class="badge badge-green">模型限制已启用</span></div>';
      }
      html += `<div class="model-tags">${models.map((m) => `<span class="model-tag">${escapeHtml(m)}</span>`).join('')}</div></div>`;
    }
  }

  return html;
}

function renderSub2apiDetail(data) {
  let html = '';

  html += '<div class="detail-section">';
  html += '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:12px;">';
  html += `<span style="font-weight:700;font-size:14px;">📊 ${escapeHtml(data.planName || 'Sub2API')}</span>`;
  const modeMap = { quota_limited: '额度限制', unrestricted: '无限制' };
  const modeLabel = modeMap[data.mode] || data.mode || '未知';
  const modeColor = data.mode === 'unrestricted' ? 'badge-green' : 'badge-orange';
  html += `<span class="badge ${modeColor}">${escapeHtml(modeLabel)}</span>`;
  if (data.status) html += `<span class="badge badge-green">${escapeHtml(data.status)}</span>`;
  if (data.isValid === false) html += '<span class="badge badge-red">无效</span>';
  html += '</div>';

  if (data.quota && data.quota.limit > 0) {
    const used = Number(data.quota.used || 0);
    const limit = Number(data.quota.limit || 0);
    const remain = Number(data.quota.remaining ?? (limit - used));

    html += renderUsageSummary([
      { label: '剩余', value: toUSDDirect(remain), cls: 'success' },
      { label: '已用', value: toUSDDirect(used), cls: 'warning' },
      { label: '总额', value: toUSDDirect(limit) },
    ]);
    html += renderProgressBar('使用率', used, limit);
  } else if (data.mode === 'unrestricted') {
    html += '<span class="badge badge-green">无限额度</span>';
    if (data.balance !== undefined) html += ` <span class="text-muted" style="font-size:12px;">余额: ${toUSDDirect(data.balance)}</span>`;
    html += '<br>';
  }
  html += '</div>';

  if (data.usage) {
    html += '<div class="detail-section"><div class="detail-section-title">用量统计</div>';
    html += '<div class="usage-stats-grid">';
    if (data.usage.rpm !== undefined) {
      html += `<div class="usage-stat"><div class="usage-stat-label">RPM</div><div class="usage-stat-value">${fmtNum(data.usage.rpm)}</div></div>`;
    }
    if (data.usage.tpm !== undefined) {
      html += `<div class="usage-stat"><div class="usage-stat-label">TPM</div><div class="usage-stat-value">${fmtNum(data.usage.tpm)}</div></div>`;
    }
    if (data.usage.average_duration_ms) {
      html += `<div class="usage-stat"><div class="usage-stat-label">平均延迟</div><div class="usage-stat-value">${(data.usage.average_duration_ms / 1000).toFixed(1)}s</div></div>`;
    }
    const today = data.usage.today;
    if (today) {
      html += `<div class="usage-stat"><div class="usage-stat-label">今日请求</div><div class="usage-stat-value">${fmtNum(today.requests)}</div></div>`;
      html += `<div class="usage-stat"><div class="usage-stat-label">今日花费</div><div class="usage-stat-value">${toUSDDirect(today.cost)}</div></div>`;
      html += `<div class="usage-stat"><div class="usage-stat-label">今日 Tokens</div><div class="usage-stat-value">${fmtNum(today.total_tokens)}</div></div>`;
    }
    html += '</div></div>';
  }

  if (data.model_stats && data.model_stats.length > 0) {
    const stats = data.model_stats.slice().sort((a, b) => (b.cost || 0) - (a.cost || 0));
    html += `<div class="detail-section"><div class="detail-section-title">模型用量明细 (${stats.length})</div>`;
    html += '<div class="table-container"><table class="usage-table">';
    html += '<thead><tr><th>模型</th><th class="num">请求数</th><th class="num">输入</th><th class="num">输出</th><th class="num">缓存读取</th><th class="num">花费</th></tr></thead><tbody>';
    stats.forEach((m) => {
      html += `<tr>
        <td><span class="model-tag">${escapeHtml(m.model)}</span></td>
        <td class="num">${fmtNum(m.requests)}</td>
        <td class="num">${fmtNum(m.input_tokens)}</td>
        <td class="num">${fmtNum(m.output_tokens)}</td>
        <td class="num">${fmtNum(m.cache_read_tokens)}</td>
        <td class="num">${toUSDDirect(m.cost)}</td>
      </tr>`;
    });
    html += '</tbody></table></div></div>';
  }

  return html;
}

function renderOneApiDetail(data) {
  let html = '';

  html += '<div class="detail-section">';
  html += '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:12px;">';
  html += '<span class="badge badge-blue">OneAPI</span>';
  if (data.username) html += `<span style="font-weight:700;font-size:14px;">${escapeHtml(data.display_name || data.username)}</span>`;
  const roleMap = { 1: '普通用户', 10: '管理员', 100: '超级管理员' };
  if (data.role !== undefined) html += `<span class="badge badge-green">${escapeHtml(roleMap[data.role] || '角色 ' + data.role)}</span>`;
  if (data.status === 2) html += '<span class="badge badge-red">已禁用</span>';
  if (data.email) html += `<span class="text-muted" style="font-size:12px;">${escapeHtml(data.email)}</span>`;
  html += '</div>';

  const quota = Number(data.quota || 0);
  const usedQuota = Number(data.used_quota || 0);
  const totalQuota = quota + usedQuota;

  html += renderUsageSummary([
    { label: '可用', value: toUSD(quota), sub: fmtNum(quota), cls: 'success' },
    { label: '已用', value: toUSD(usedQuota), sub: fmtNum(usedQuota), cls: 'warning' },
    { label: '总额', value: toUSD(totalQuota), sub: fmtNum(totalQuota) },
  ]);
  html += renderProgressBar('使用率', usedQuota, totalQuota);
  html += '</div>';

  // Additional info
  html += '<div class="detail-section"><div class="detail-section-title">账户信息</div>';
  html += '<div class="table-container"><table class="usage-table">';
  html += '<tbody>';
  if (data.request_count !== undefined) html += `<tr><td>请求总数</td><td class="num">${fmtNum(data.request_count)}</td></tr>`;
  if (data.group) html += `<tr><td>用户组</td><td>${escapeHtml(data.group)}</td></tr>`;
  if (data.created_time) html += `<tr><td>创建时间</td><td>${new Date(data.created_time * 1000).toLocaleString('zh-CN')}</td></tr>`;
  if (data.access_token) html += `<tr><td>Access Token</td><td style="font-family:var(--font-mono);font-size:10px;">${escapeHtml(data.access_token.slice(0, 8))}...${escapeHtml(data.access_token.slice(-4))}</td></tr>`;
  html += '</tbody></table></div></div>';

  return html;
}

function renderOpenAIDetail(data) {
  let html = '';
  html += '<div class="detail-section">';
  html += '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:12px;">';
  html += '<span class="badge badge-green">OpenAI 兼容</span>';
  if (data && data._openaiUsageType === 'billing') {
    html += '<span class="badge badge-blue">Billing</span>';
  }
  html += '</div>';

  if (data && data._openaiUsageType === 'billing') {
    const total = Number(data.total_granted || data.hard_limit_usd || 0);
    const used = Number(data.total_used || 0);
    const available = Number(data.total_available ?? Math.max(total - used, 0));

    html += '<div class="detail-section-title">额度概览</div>';
    html += renderUsageSummary([
      { label: '可用', value: toUSDDirect(available), cls: 'success' },
      { label: '已用', value: toUSDDirect(used), cls: 'warning' },
      { label: '总额', value: toUSDDirect(total) },
    ]);
    html += renderProgressBar('使用率', used, total);

    html += '<div class="detail-section-title" style="margin-top:12px;">计费信息</div>';
    html += '<div class="table-container"><table class="usage-table"><tbody>';
    if (data.plan) html += `<tr><td>套餐</td><td>${escapeHtml(data.plan)}</td></tr>`;
    if (data.access_until) {
      const expiryStr = formatExpiry(data.access_until);
      if (expiryStr) html += `<tr><td>到期时间</td><td>${expiryStr}</td></tr>`;
    }
    if (data.has_payment_method !== null && data.has_payment_method !== undefined) {
      html += `<tr><td>支付方式</td><td>${data.has_payment_method ? '已绑定' : '未绑定'}</td></tr>`;
    }
    html += `<tr><td>可用额度</td><td class="num">${toUSDDirect(available)}</td></tr>`;
    html += `<tr><td>已用额度</td><td class="num">${toUSDDirect(used)}</td></tr>`;
    html += `<tr><td>总额度</td><td class="num">${toUSDDirect(total)}</td></tr>`;
    html += '</tbody></table></div>';
    html += '</div>';
    return html;
  }

  let models = [];
  if (Array.isArray(data)) {
    models = data;
  } else if (data && Array.isArray(data.data)) {
    models = data.data;
  }

  if (models.length > 0) {
    const modelIds = models.map((m) => m.id || m.name || JSON.stringify(m)).sort((a, b) => a.localeCompare(b));
    html += `<div class="detail-section-title">可用模型 (${modelIds.length})</div>`;
    html += '<div class="model-tags" style="max-height:300px;overflow-y:auto;">';
    html += modelIds.map((m) => `<span class="model-tag">${escapeHtml(m)}</span>`).join('');
    html += '</div>';
  } else {
    html += '<p class="text-muted">未检测到可用模型</p>';
  }
  html += '</div>';

  return html;
}

function openDetailModal(site, result) {
  detailTitle.textContent = site.name + ' — 额度详情';
  const data = result.data;
  const format = result.format;

  if (!data) {
    detailContent.innerHTML = '<div class="error-message"><span>响应中无数据</span></div>';
    detailModal.style.display = '';
    return;
  }

  let html = '';
  if (format === 'sub2api') {
    html = renderSub2apiDetail(data);
  } else if (format === 'cch') {
    html = renderCCHDetail(data);
  } else if (format === 'one-api') {
    html = renderOneApiDetail(data);
  } else if (format === 'openai') {
    html = renderOpenAIDetail(data);
  } else {
    html = renderNewApiDetail(data);
  }

  html += `
    <div class="detail-section">
      <div class="detail-section-title">原始响应</div>
      <details>
        <summary style="cursor:pointer;color:var(--text-tertiary);font-size:11px;margin-bottom:4px;">展开 JSON</summary>
        <pre style="font-size:10px;color:var(--text-secondary);background:var(--bg-primary);padding:8px;border-radius:var(--radius-sm);overflow-x:auto;max-height:200px;white-space:pre-wrap;word-break:break-all;">${escapeHtml(JSON.stringify(data, null, 2))}</pre>
      </details>
    </div>
  `;

  detailContent.innerHTML = html;
  detailModal.style.display = '';
}

function closeDetailModal() {
  detailModal.style.display = 'none';
}

async function queryAndShowModels(site) {
  detailTitle.textContent = site.name + ' — 可用模型';
  detailContent.innerHTML = `
    <div class="loading-spinner" style="padding:24px 0;justify-content:center;">
      <div class="spinner"></div> 正在查询模型列表...
    </div>
  `;
  detailModal.style.display = '';

  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { action: 'queryModels', site },
      (response) => {
        if (chrome.runtime.lastError) {
          detailContent.innerHTML = `<div class="error-message"><span>通信错误: ${escapeHtml(chrome.runtime.lastError.message)}</span></div>`;
        } else if (response && response.success) {
          renderModelsModal(site, response.data);
        } else {
          detailContent.innerHTML = `<div class="error-message"><span>${escapeHtml((response && response.error) || '未知错误')}</span></div>`;
        }
        resolve();
      },
    );
  });
}

function renderModelsModal(_site, data) {
  let models = [];
  if (Array.isArray(data)) {
    models = data;
  } else if (data && Array.isArray(data.data)) {
    models = data.data;
  } else {
    detailContent.innerHTML = '<div class="error-message"><span>无法解析模型列表</span></div>';
    return;
  }

  const modelIds = models.map((m) => m.id || m.name || JSON.stringify(m)).sort((a, b) => a.localeCompare(b));

  let html = '';
  html += `<div class="detail-section"><div class="detail-section-title">可用模型 (${modelIds.length})</div>`;

  html += '<input type="text" id="modelSearchInput" placeholder="搜索模型..." style="width:100%;padding:6px 10px;font-size:12px;margin-bottom:8px;background:var(--bg-input);border:1px solid var(--border-primary);border-radius:var(--radius-sm);color:var(--text-primary);outline:none;font-family:var(--font-family);">';

  html += '<div id="modelListContainer" class="model-tags" style="max-height:350px;overflow-y:auto;">';
  html += modelIds.map((id) => `<span class="model-tag model-item" data-model="${id.toLowerCase().replace(/"/g, '&quot;')}">${escapeHtml(id)}</span>`).join('');
  html += '</div></div>';

  html += `
    <div class="detail-section">
      <div class="detail-section-title">原始响应</div>
      <details>
        <summary style="cursor:pointer;color:var(--text-tertiary);font-size:11px;margin-bottom:4px;">展开 JSON</summary>
        <pre style="font-size:10px;color:var(--text-secondary);background:var(--bg-primary);padding:8px;border-radius:var(--radius-sm);overflow-x:auto;max-height:200px;white-space:pre-wrap;word-break:break-all;">${escapeHtml(JSON.stringify(data, null, 2))}</pre>
      </details>
    </div>
  `;

  detailContent.innerHTML = html;

  const searchEl = document.getElementById('modelSearchInput');
  const container = document.getElementById('modelListContainer');
  if (searchEl && container) {
    searchEl.addEventListener('input', () => {
      const q = searchEl.value.trim().toLowerCase();
      container.querySelectorAll('.model-item').forEach((tag) => {
        tag.style.display = !q || tag.dataset.model.includes(q) ? '' : 'none';
      });
    });
    searchEl.focus();
  }
}

function renderChatTestResult(site, result, modelsList) {
  detailTitle.textContent = site.name + ' — API 测试';
  let html = '';

  html += '<div class="detail-section">';
  html += '<div class="detail-section-title">测试信息</div>';
  html += '<div class="chat-test-meta">';
  html += `<div class="chat-test-meta-item"><span class="chat-test-meta-label">模型</span><span class="model-tag">${escapeHtml(result.model || '未知')}</span></div>`;
  html += `<div class="chat-test-meta-item"><span class="chat-test-meta-label">耗时</span><span class="chat-test-elapsed">${(result.elapsed / 1000).toFixed(2)}s</span></div>`;
  if (result.success) {
    html += `<div class="chat-test-meta-item"><span class="chat-test-meta-label">状态</span><span class="badge badge-green">成功</span></div>`;
  } else {
    html += `<div class="chat-test-meta-item"><span class="chat-test-meta-label">状态</span><span class="badge badge-red">失败</span></div>`;
  }
  html += '</div></div>';

  if (result.success) {
    html += '<div class="detail-section">';
    html += '<div class="detail-section-title">对话</div>';
    html += '<div class="chat-test-conversation">';
    html += '<div class="chat-bubble chat-bubble-user"><div class="chat-bubble-role">User</div><div class="chat-bubble-content">Hi</div></div>';
    html += `<div class="chat-bubble chat-bubble-assistant"><div class="chat-bubble-role">Assistant (${escapeHtml(result.model || '')})</div><div class="chat-bubble-content">${escapeHtml(result.content || '(空回复)')}</div></div>`;
    html += '</div></div>';

    if (result.usage) {
      html += '<div class="detail-section"><div class="detail-section-title">Token 用量</div>';
      html += '<div class="usage-stats-grid">';
      if (result.usage.prompt_tokens !== undefined) {
        html += `<div class="usage-stat"><div class="usage-stat-label">输入</div><div class="usage-stat-value">${fmtNum(result.usage.prompt_tokens)}</div></div>`;
      }
      if (result.usage.completion_tokens !== undefined) {
        html += `<div class="usage-stat"><div class="usage-stat-label">输出</div><div class="usage-stat-value">${fmtNum(result.usage.completion_tokens)}</div></div>`;
      }
      if (result.usage.total_tokens !== undefined) {
        html += `<div class="usage-stat"><div class="usage-stat-label">总计</div><div class="usage-stat-value">${fmtNum(result.usage.total_tokens)}</div></div>`;
      }
      html += '</div></div>';
    }

    html += `<div class="detail-section"><div class="detail-section-title">原始响应</div>
      <details>
        <summary style="cursor:pointer;color:var(--text-tertiary);font-size:11px;margin-bottom:4px;">展开 JSON</summary>
        <pre style="font-size:10px;color:var(--text-secondary);background:var(--bg-primary);padding:8px;border-radius:var(--radius-sm);overflow-x:auto;max-height:200px;white-space:pre-wrap;word-break:break-all;">${escapeHtml(JSON.stringify(result.raw, null, 2))}</pre>
      </details>
    </div>`;
  } else {
    html += `<div class="detail-section"><div class="error-message"><span>${escapeHtml(result.error || '未知错误')}</span></div></div>`;
  }

  // Model picker for retest
  const modelsArr = Array.isArray(modelsList) ? modelsList : [];
  html += '<div class="detail-section">';
  html += `<div class="detail-section-title">换个模型再试 <span class="text-muted" style="font-weight:400;font-size:11px;">(${modelsArr.length} 个可用)</span></div>`;
  html += '<div class="chat-test-retest">';
  html += `<div class="chat-test-retest-input-row">
    <input type="text" id="chatTestModelInput" placeholder="搜索或输入模型名…" value="${escapeHtml(result.model || '')}" autocomplete="off">
    <button id="chatTestRetestBtn" class="btn btn-sm btn-primary">重新测试</button>
  </div>`;
  if (modelsArr.length > 0) {
    html += `<div id="chatTestModelList" class="chat-test-model-list">`;
    html += modelsArr.map((id) => {
      const active = id === result.model ? ' chat-test-model-active' : '';
      return `<span class="model-tag chat-test-model-option${active}" data-model-id="${escapeHtml(id)}">${escapeHtml(id)}</span>`;
    }).join('');
    html += '</div>';
  }
  html += '</div></div>';

  detailContent.innerHTML = html;
  detailModal.style.display = '';

  // Bind events for model picker
  const modelInput = document.getElementById('chatTestModelInput');
  const retestBtn = document.getElementById('chatTestRetestBtn');
  const modelListEl = document.getElementById('chatTestModelList');

  if (modelInput && modelListEl) {
    modelInput.addEventListener('input', () => {
      const q = modelInput.value.trim().toLowerCase();
      modelListEl.querySelectorAll('.chat-test-model-option').forEach((tag) => {
        tag.style.display = !q || tag.dataset.modelId.toLowerCase().includes(q) ? '' : 'none';
      });
    });

    modelListEl.addEventListener('click', (e) => {
      const target = e.target;
      if (!(target instanceof Element)) return;
      const opt = target.closest('.chat-test-model-option');
      if (!opt || !opt.dataset.modelId) return;
      modelInput.value = opt.dataset.modelId;
      // Update active highlight
      modelListEl.querySelectorAll('.chat-test-model-active').forEach((el) => el.classList.remove('chat-test-model-active'));
      opt.classList.add('chat-test-model-active');
    });
  }

  if (retestBtn && modelInput) {
    retestBtn.addEventListener('click', () => {
      const model = modelInput.value.trim();
      if (!model) {
        showToast('请输入或选择模型', 'error');
        return;
      }
      chatTestSite(site, model);
    });
  }

}

function setFormTags(tags) {
  formTags = sanitizeTags(tags);
  renderFormTags();
  saveDraft();
}

function addFormTag(tag) {
  const next = sanitizeTags([...formTags, tag]);
  if (next.length === formTags.length) return;
  formTags = next;
  renderFormTags();
  saveDraft();
}

function removeFormTag(tag) {
  const key = String(tag || '').toLowerCase();
  formTags = formTags.filter((item) => item.toLowerCase() !== key);
  renderFormTags();
  saveDraft();
}

function renderFormTags() {
  siteTagsContainer.innerHTML = formTags.map((tag) => `
    <span class="tag-chip">
      ${escapeHtml(tag)}
      <span class="tag-chip-remove" data-tag="${escapeHtml(tag)}" title="删除">×</span>
    </span>
  `).join('');
}

function hideTagsAutocomplete() {
  tagsAutocomplete.style.display = 'none';
  tagsAutocomplete.innerHTML = '';
}

function renderTagsAutocomplete() {
  const q = (siteTagsInput.value || '').trim().toLowerCase();
  const candidates = getAllTags().filter((tag) => {
    if (formTags.some((existing) => existing.toLowerCase() === tag.toLowerCase())) return false;
    if (!q) return true;
    return tag.toLowerCase().includes(q);
  });

  if (candidates.length === 0) {
    hideTagsAutocomplete();
    return;
  }

  tagsAutocomplete.innerHTML = candidates.slice(0, 8).map((tag) => `
    <div class="tags-autocomplete-item" data-tag="${escapeHtml(tag)}">${escapeHtml(tag)}</div>
  `).join('');
  tagsAutocomplete.style.display = '';
}

function commitTagsFromInput() {
  const parts = parseTagsFromText(siteTagsInput.value);
  if (!parts.length) return;
  for (const tag of parts) {
    addFormTag(tag);
  }
  siteTagsInput.value = '';
  hideTagsAutocomplete();
}

function renderBatchPreview() {
  const commonTags = sanitizeTags(parseTagsFromText(batchTagsInput.value));
  const { parsed, invalidCount } = parseBatchImportLines(batchInput.value, commonTags);
  batchParsedSites = parsed;

  if (parsed.length === 0) {
    batchPreview.style.display = 'none';
    btnDoBatch.disabled = true;
    return;
  }

  const sample = parsed.slice(0, 8);
  batchPreview.innerHTML = `
    <div class="preview-item"><strong>可导入 ${parsed.length} 项</strong>${invalidCount > 0 ? `，忽略 ${invalidCount} 行` : ''}</div>
    ${sample.map((site) => `<div class="preview-item"><span class="preview-url">${escapeHtml(site.baseUrl)}</span><span class="preview-key">${escapeHtml(site.name)}</span></div>`).join('')}
    ${parsed.length > sample.length ? `<div class="preview-item text-muted">... 还有 ${parsed.length - sample.length} 项</div>` : ''}
  `;
  batchPreview.style.display = '';
  btnDoBatch.disabled = false;
}

function renderImportPreview(parsedSites, rawPayload) {
  if (!parsedSites.length) {
    importPreview.style.display = 'none';
    btnDoImport.disabled = true;
    return;
  }

  const schemaVersion = rawPayload && typeof rawPayload === 'object' ? rawPayload.schemaVersion : 'legacy';
  const exportedAt = rawPayload && typeof rawPayload === 'object' ? rawPayload.exportedAt : null;
  const previewItems = parsedSites.slice(0, 5);

  importPreview.innerHTML = `
    <div class="preview-item"><strong>共 ${parsedSites.length} 个站点</strong></div>
    <div class="preview-item">Schema: ${escapeHtml(String(schemaVersion || 'legacy'))}</div>
    ${exportedAt ? `<div class="preview-item">导出时间: ${escapeHtml(String(exportedAt))}</div>` : ''}
    ${previewItems.map((s) => `<div class="preview-item"><span class="preview-url">${escapeHtml(s.baseUrl)}</span><span class="preview-key">${escapeHtml(s.name || '')}</span></div>`).join('')}
    ${parsedSites.length > previewItems.length ? `<div class="preview-item text-muted">... 还有 ${parsedSites.length - previewItems.length} 项</div>` : ''}
  `;
  importPreview.style.display = '';
  btnDoImport.disabled = false;
}
