/**
 * AI API Toolkit — Shared Constants
 * Loaded first; available to all scripts via global scope.
 */

// OneAPI/new-api 额度单位: 1 USD = 500,000 内部单位
var QUOTA_PER_USD = 500000;

// 剪贴板自动检测轮询间隔 (ms)
var CLIPBOARD_POLL_MS = 5000;

// chrome.storage.local 键名
var DRAFT_KEY = '_formDraft';
var THEME_KEY = 'theme';

// 后台管理面板常用路径
var BACKEND_PATHS = [
  '/',
  '/admin',
  '/panel',
  '/dashboard',
  '/console',
  '/log',
  '/topup',
  '/token',
  '/setting',
  '/login',
];
