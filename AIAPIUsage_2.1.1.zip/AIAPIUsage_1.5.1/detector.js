/**
 * AI API Toolkit — Page Key Detector
 * Injected on-demand via chrome.scripting.executeScript.
 * Scans VIEWPORT for API keys, pairing with URLs from adjacent lines.
 *
 * URL pairing strategy (priority order):
 * 1. Same line / same element text
 * 2. Previous sibling element (line above) — text + <a> hrefs
 * 3. Next sibling element (line below) — text + <a> hrefs
 * 4. Give up (no URL paired)
 */
(() => {
  const KEY_RE = /\bsk-[a-zA-Z0-9_\-]{12,}\b/g;
  const URL_RE = /https?:\/\/[a-zA-Z0-9][-a-zA-Z0-9._]*[a-zA-Z0-9](?::\d+)?(?:\/[^\s'",<>(){}[\]]*)?/g;
  const NON_API_HOSTS = /\b(github\.com|google\.com|youtube\.com|twitter\.com|facebook\.com|imgur\.com|reddit\.com|stackoverflow\.com|cdn\.|fonts\.|analytics\.)\b/i;

  const seenKeys = new Set();
  const results = [];

  function maskKey(k) {
    return k.length > 12
      ? k.slice(0, 5) + '***' + k.slice(-4)
      : k.slice(0, 3) + '***';
  }

  function addResult(key, url, source) {
    const k = key.trim();
    if (!k) return;
    if (seenKeys.has(k)) {
      // Upgrade: if existing result has no URL but this one does, update it
      if (url) {
        const existing = results.find((r) => r.key === k);
        if (existing && !existing.inferredBaseUrl) {
          existing.inferredBaseUrl = url;
          existing.source = source;
        }
      }
      return;
    }
    seenKeys.add(k);
    results.push({
      key: k,
      maskedKey: maskKey(k),
      inferredBaseUrl: url || '',
      source,
    });
  }

  // --- Viewport check ---
  function isInViewport(el) {
    const rect = el.getBoundingClientRect();
    return (
      rect.bottom > 0 &&
      rect.top < window.innerHeight &&
      rect.right > 0 &&
      rect.left < window.innerWidth
    );
  }

  // --- Extract API-like URLs from plain text ---
  function extractUrlsFromText(text) {
    const urls = [];
    if (!text) return urls;
    for (const m of text.matchAll(URL_RE)) {
      let u = m[0].replace(/[.,;:!?)]+$/, '');
      if (NON_API_HOSTS.test(u)) continue;
      const base = u.replace(/\/+$/, '').replace(/\/v1$/i, '');
      if (base && !urls.includes(base)) urls.push(base);
    }
    return urls;
  }

  // --- Extract API-like URLs from <a> href attributes within an element ---
  function extractUrlsFromLinks(el) {
    const urls = [];
    if (!el) return urls;
    // Check the element itself if it's an <a>
    if (el.tagName === 'A' && el.href) {
      const href = el.href;
      URL_RE.lastIndex = 0;
      if (URL_RE.test(href) && !NON_API_HOSTS.test(href)) {
        URL_RE.lastIndex = 0;
        const base = href.replace(/\/+$/, '').replace(/\/v1$/i, '');
        if (base) urls.push(base);
      }
      URL_RE.lastIndex = 0;
    }
    // Check child <a> tags
    const anchors = el.querySelectorAll ? el.querySelectorAll('a[href]') : [];
    anchors.forEach((a) => {
      const href = a.href || '';
      if (!href) return;
      URL_RE.lastIndex = 0;
      if (!URL_RE.test(href)) { URL_RE.lastIndex = 0; return; }
      URL_RE.lastIndex = 0;
      if (NON_API_HOSTS.test(href)) return;
      const base = href.replace(/\/+$/, '').replace(/\/v1$/i, '');
      if (base && !urls.includes(base)) urls.push(base);
    });
    return urls;
  }

  // --- Extract all URLs from an element (text + links) ---
  function extractAllUrls(el) {
    if (!el) return [];
    const textUrls = extractUrlsFromText((el.textContent || '').trim());
    const linkUrls = extractUrlsFromLinks(el);
    const all = [...textUrls];
    for (const u of linkUrls) {
      if (!all.includes(u)) all.push(u);
    }
    return all;
  }

  // --- Find the block-level ancestor that represents a visual "line" ---
  const BLOCK_TAGS = new Set([
    'P', 'LI', 'DIV', 'TR', 'BLOCKQUOTE', 'PRE',
    'ARTICLE', 'SECTION', 'ASIDE', 'HEADER', 'FOOTER', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6',
  ]);

  function getLineElement(el) {
    let current = el;
    while (current && current !== document.body) {
      if (BLOCK_TAGS.has(current.tagName)) return current;
      current = current.parentElement;
    }
    return el;
  }

  // --- Strategy 1: Scan viewport elements with adjacent-line URL pairing ---
  function scanViewport() {
    const elements = document.querySelectorAll(
      'p, li, div, td, th, code, pre, blockquote, span, article, section, ' +
      '.post-content, .message-body, .bbcode, .markdown-body, [class*="content"], [class*="post"]'
    );

    elements.forEach((el) => {
      // Only scan elements visible in viewport
      if (!isInViewport(el)) return;
      // Skip large container elements — focus on leaf-ish nodes
      if (el.children.length > 20) return;
      // Skip containers that have block-level children (prefer scanning the children directly)
      const hasBlockChildren = Array.from(el.children).some((c) => BLOCK_TAGS.has(c.tagName));
      if (hasBlockChildren) return;
      const text = (el.textContent || '').trim();
      if (!text || text.length > 10000) return;

      const keys = [...text.matchAll(KEY_RE)].map((m) => m[0]);
      if (keys.length === 0) return;

      // 1. Try same element text for URL
      let urls = extractUrlsFromText(text);

      if (urls.length === 0) {
        // 2. Go to block-level "line" element
        const lineEl = getLineElement(el);

        // 3. Check up to 2 previous siblings (lines above — priority)
        let sib = lineEl.previousElementSibling;
        for (let i = 0; i < 2 && sib && urls.length === 0; i++) {
          urls = extractAllUrls(sib);
          sib = sib.previousElementSibling;
        }

        // 4. If not found, check up to 2 next siblings (lines below)
        sib = lineEl.nextElementSibling;
        for (let i = 0; i < 2 && sib && urls.length === 0; i++) {
          urls = extractAllUrls(sib);
          sib = sib.nextElementSibling;
        }
      }

      const bestUrl = urls.length > 0 ? urls[0] : '';
      for (const key of keys) {
        addResult(key, bestUrl, bestUrl ? 'paired' : 'text');
      }
    });
  }

  // --- Strategy 2: Scan input values (viewport only) ---
  function scanInputs() {
    document.querySelectorAll('input, textarea').forEach((el) => {
      if (!isInViewport(el)) return;
      const val = (el.value || '').trim();
      if (!val) return;
      const nameLC = (el.name + ' ' + el.placeholder + ' ' + el.id + ' ' + el.className).toLowerCase();
      const isKeyField = /key|token|secret|apikey|api_key/.test(nameLC);
      if (isKeyField && val.length >= 10) {
        addResult(val, '', 'input');
      }
      for (const m of val.matchAll(KEY_RE)) {
        addResult(m[0], '', 'input');
      }
    });
  }

  // --- Strategy 3: Clipboard data attributes (viewport only) ---
  function scanClipboard() {
    document.querySelectorAll('[data-clipboard-text], [data-copy]').forEach((el) => {
      if (!isInViewport(el)) return;
      const val = el.dataset.clipboardText || el.dataset.copy || '';
      for (const m of val.matchAll(KEY_RE)) {
        addResult(m[0], '', 'clipboard');
      }
    });
  }

  // Run all strategies
  scanViewport();
  scanInputs();
  scanClipboard();

  return results;
})();
